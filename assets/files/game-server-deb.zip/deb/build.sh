#!/bin/bash

dotnet publish ../src/hosts/Sailina.Tang.Game.Host/Sailina.Tang.Game.Host.csproj -o ./server/usr/local/tang/server/ --no-self-contained -r linux-x64 -c Realase
dotnet publish ../src/hosts/Sailina.Tang.Management.Host/Sailina.Tang.Management.Host.csproj -o ./server/usr/local/tang/mgmt/ --no-self-contained -r linux-x64 -c Release
rm -Rf ./server/usr/local/tang/server/appsettings.json
rm -Rf ./server/usr/local/tang/mgmt/appsettings.json
mv ./server/usr/local/tang/server/Sailina.Tang.Game.Host ./server/usr/local/tang/server/tang-server
chmod 755 ./server -R
dpkg -b server tang-game-server.deb