#!/bin/bash
ssh ubuntu@43.155.78.26 "sudo systemctl stop tang"

ssh ubuntu@43.155.105.96 "sudo systemctl stop tang"

ssh ubuntu@43.155.118.66 "sudo systemctl stop tang"


