#!/bin/bash
ssh ubuntu@43.155.78.26 "sudo dpkg -r tang-game-server"
ssh ubuntu@43.155.78.26 "sudo dpkg -i tang-game-server.deb && sudo systemctl start tang"

ssh ubuntu@43.155.105.96 "sudo dpkg -r tang-game-server"
ssh ubuntu@43.155.105.96 "sudo dpkg -i tang-game-server.deb && sudo systemctl start tang"

ssh ubuntu@43.155.118.66 "sudo dpkg -r tang-game-server"
ssh ubuntu@43.155.118.66 "sudo dpkg -i tang-game-server.deb && sudo systemctl start tang"


