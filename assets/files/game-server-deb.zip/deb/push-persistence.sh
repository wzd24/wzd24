#!/bin/bash
scp tang-game-persistence.deb ubuntu@43.154.230.252:~
scp tang-game-persistence.deb ubuntu@43.134.194.222:~