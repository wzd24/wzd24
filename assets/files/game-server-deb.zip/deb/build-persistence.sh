#!/bin/bash

dotnet publish ../src/hosts/Sailina.Tang.Persistence.Host/Sailina.Tang.Persistence.Host.csproj -o ./persistence/usr/local/tang/persistence/ --no-self-contained -r linux-x64 -c Realase
rm -Rf ./persistence/usr/local/tang/persistence/appsettings.json
mv ./persistence/usr/local/tang/persistence/Sailina.Tang.Persistence.Host ./persistence/usr/local/tang/persistence/tang-persistence
chmod 755 ./persistence -R
dpkg -b persistence tang-game-persistence.deb