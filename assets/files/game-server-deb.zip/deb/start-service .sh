#!/bin/bash
ssh ubuntu@43.155.78.26 "sudo systemctl start tang"

ssh ubuntu@43.155.105.96 "sudo systemctl start tang"

ssh ubuntu@43.155.118.66 "sudo systemctl start tang"


