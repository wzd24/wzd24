#!/bin/bash
ssh ubuntu@43.154.230.252 "sudo dpkg -r tang-game-persistence"
ssh ubuntu@43.154.230.252 "sudo dpkg -i tang-game-persistence.deb && sudo systemctl start persistence"
ssh ubuntu@43.134.194.222 "sudo dpkg -r tang-game-persistence"
ssh ubuntu@43.134.194.222 "sudo dpkg -i tang-game-persistence.deb && sudo systemctl start persistence"


