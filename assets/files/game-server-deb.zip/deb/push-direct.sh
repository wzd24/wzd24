#!/bin/bash
scp tang-game-server.deb ubuntu@43.155.78.26:~
scp tang-game-server.deb ubuntu@43.155.105.96:~
scp tang-game-server.deb ubuntu@43.155.118.66:~