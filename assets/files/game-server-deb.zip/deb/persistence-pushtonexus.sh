#!/bin/bash
curl -v -u admin:Sailina@2021 -X POST 'http://nexus.devops.xmsailina.com/service/rest/v1/components?repository=apt-get' -F "apt.asset=@tang-game-persistence.deb"
curl -v -u admin:Sailina@2021 -X POST 'http://nexus.devops.xmsailina.com/service/rest/v1/components?repository=tang-apt' -F "apt.asset=@tang-game-persistence.deb"
