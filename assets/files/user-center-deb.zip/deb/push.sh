#!/bin/bash
scp tang-ucenter-server.deb root@35.206.255.205:~
