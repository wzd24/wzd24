#!/bin/bash
dotnet publish ../src/Sailina.UCenter.Host/Sailina.UCenter.Host.csproj -o ./server/usr/local/ucenter/ --no-self-contained -r linux-x64 -c Realase
rm -Rf ./server/usr/local/ucenter/appsettings.json
rm -Rf ./server/usr/local/ucenter/redis.json
mv ./server/usr/local/ucenter/Sailina.UCenter.Host ./server/usr/local/ucenter/ucenter-server
chmod 755 ./server -R
dpkg -b server tang-ucenter-server.deb