#!/bin/bash
ssh ubuntu@43.155.94.45 "sudo dpkg -r tang-ucenter-server"
ssh ubuntu@43.155.94.45 "sudo dpkg -i tang-ucenter-server.deb && sudo systemctl start ucenter"



