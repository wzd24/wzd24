/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50731
 Source Host           : localhost:3306
 Source Schema         : ucenter

 Target Server Type    : MySQL
 Target Server Version : 50731
 File Encoding         : 65001

 Date: 04/02/2024 16:55:08
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for __efmigrationshistory
-- ----------------------------
DROP TABLE IF EXISTS `__efmigrationshistory`;
CREATE TABLE `__efmigrationshistory`  (
  `MigrationId` varchar(95) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ProductVersion` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`MigrationId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for activitygroupsetting
-- ----------------------------
DROP TABLE IF EXISTS `activitygroupsetting`;
CREATE TABLE `activitygroupsetting`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `GroupId` int(11) NOT NULL,
  `GroupName` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ActivityCode` int(11) NOT NULL,
  `SmallType` int(11) NOT NULL,
  `ActivityName` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for activityplan
-- ----------------------------
DROP TABLE IF EXISTS `activityplan`;
CREATE TABLE `activityplan`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ServerId` int(11) NOT NULL,
  `Activity` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Days` int(11) NOT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatar
-- ----------------------------
DROP TABLE IF EXISTS `avatar`;
CREATE TABLE `avatar`  (
  `Id` bigint(20) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `UserId` bigint(20) NULL DEFAULT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `Name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `CreateDate` datetime(6) NOT NULL,
  `LastLogin` datetime(6) NULL DEFAULT NULL,
  `IsDeleted` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否已删号',
  `IsGenerate` tinyint(1) NULL DEFAULT NULL COMMENT '是否已创角',
  `GM` tinyint(1) NULL DEFAULT NULL COMMENT '是否GM账号',
  `ForbidEndTime` datetime NULL DEFAULT NULL COMMENT '封禁结束时间',
  PRIMARY KEY (`AvatarId`) USING BTREE,
  UNIQUE INDEX `IX_Avatar_AvatarId`(`AvatarId`) USING BTREE,
  UNIQUE INDEX `IX_Avatar_UserId`(`UserId`, `ServerId`) USING BTREE,
  INDEX `IX_Avatar_ServerId`(`ServerId`) USING BTREE,
  CONSTRAINT `FK_Avatar_Servers_ServerId` FOREIGN KEY (`ServerId`) REFERENCES `servers` (`Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_Avatar_Users_UserId` FOREIGN KEY (`UserId`) REFERENCES `users` (`Id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for chatlevellimitsetting
-- ----------------------------
DROP TABLE IF EXISTS `chatlevellimitsetting`;
CREATE TABLE `chatlevellimitsetting`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ServerId` int(11) NOT NULL,
  `Level` int(11) NOT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for fisrttestuser
-- ----------------------------
DROP TABLE IF EXISTS `fisrttestuser`;
CREATE TABLE `fisrttestuser`  (
  `UserId` bigint(20) NULL DEFAULT NULL,
  `HadSendEmail` int(1) NOT NULL DEFAULT 0
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for games
-- ----------------------------
DROP TABLE IF EXISTS `games`;
CREATE TABLE `games`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `IsDeleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for giftpackagesetting
-- ----------------------------
DROP TABLE IF EXISTS `giftpackagesetting`;
CREATE TABLE `giftpackagesetting`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Type` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Content` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `IsRepeat` tinyint(1) NULL DEFAULT NULL,
  `ValidTime` datetime NULL DEFAULT NULL,
  `RedeemCodeChar` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `Reward` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `AvailableNum` int(11) NULL DEFAULT NULL,
  `File` varchar(300) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for groupservers
-- ----------------------------
DROP TABLE IF EXISTS `groupservers`;
CREATE TABLE `groupservers`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `GroupServerId` int(11) NULL DEFAULT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `ix_groupservers_key`(`ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for hotkeyactivitysetting
-- ----------------------------
DROP TABLE IF EXISTS `hotkeyactivitysetting`;
CREATE TABLE `hotkeyactivitysetting`  (
  `HotKeyName` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Activities` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for infractionwordsetting
-- ----------------------------
DROP TABLE IF EXISTS `infractionwordsetting`;
CREATE TABLE `infractionwordsetting`  (
  `word` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for loginlog
-- ----------------------------
DROP TABLE IF EXISTS `loginlog`;
CREATE TABLE `loginlog`  (
  `Id` bigint(20) NOT NULL,
  `Date` datetime NULL DEFAULT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `Uid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Puid` bigint(20) NULL DEFAULT NULL,
  `Ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `OS` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `DateNum` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `id`(`Id`) USING BTREE,
  INDEX `DS`(`DateNum`, `ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for redeemcodesetting
-- ----------------------------
DROP TABLE IF EXISTS `redeemcodesetting`;
CREATE TABLE `redeemcodesetting`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `GiftId` int(11) NOT NULL,
  `RedeemCode` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `AvatarIds` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `IsRepeat` tinyint(1) NULL DEFAULT NULL,
  `UsedNum` int(11) NULL DEFAULT NULL,
  `AvailableNum` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for registerlog
-- ----------------------------
DROP TABLE IF EXISTS `registerlog`;
CREATE TABLE `registerlog`  (
  `Id` bigint(20) NOT NULL,
  `Date` datetime NULL DEFAULT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `Uid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Puid` bigint(20) NULL DEFAULT NULL,
  `Ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `OS` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `DateNum` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `id`(`Id`) USING BTREE,
  INDEX `DS`(`DateNum`, `ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for servers
-- ----------------------------
DROP TABLE IF EXISTS `servers`;
CREATE TABLE `servers`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `IsVisiable` tinyint(1) NOT NULL,
  `CanRegister` tinyint(1) NOT NULL DEFAULT 0,
  `CreateDate` datetime(6) NOT NULL DEFAULT '0001-01-01 00:00:00.000000',
  `IsDeleted` tinyint(1) NOT NULL DEFAULT 0,
  `LastMaintenanceDate` datetime(6) NOT NULL DEFAULT '0001-01-01 00:00:00.000000',
  `Status` int(11) NOT NULL DEFAULT 0,
  `Tags` int(11) NOT NULL DEFAULT 0,
  `OpenTime` datetime(6) NOT NULL,
  `Group` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `OpSid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10000 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;


-- ----------------------------
-- Table structure for serviceverurl
-- ----------------------------
DROP TABLE IF EXISTS `serviceverurl`;
CREATE TABLE `serviceverurl`  (
  `Id` int(11) NOT NULL,
  `Version` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `UCenterUrl` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `GameUrl` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `State` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `LoginId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Password` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `CreateDate` datetime(6) NOT NULL,
  `LastLogin` datetime(6) NULL DEFAULT NULL,
  `IsDeleted` tinyint(1) NOT NULL DEFAULT 0,
  `GM` tinyint(1) NULL DEFAULT 0,
  `Other` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `IX_Users_LoginId`(`LoginId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7055515 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for users_copy1
-- ----------------------------
DROP TABLE IF EXISTS `users_copy1`;
CREATE TABLE `users_copy1`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `LoginId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Password` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `CreateDate` datetime(6) NOT NULL,
  `LastLogin` datetime(6) NULL DEFAULT NULL,
  `IsDeleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `IX_Users_LoginId`(`LoginId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Procedure structure for GenerateAIUser
-- ----------------------------
DROP PROCEDURE IF EXISTS `GenerateAIUser`;
delimiter ;;
CREATE PROCEDURE `GenerateAIUser`(IN `sid` int,IN `name` varchar(20))
BEGIN
	#Routine body goes here...
	DECLARE `uid` int;
	DECLARE `aid` int;
	INSERT IGNORE INTO `users`(`LoginId`, `Password`, `CreateDate`) VALUES (`name`, '123123', CURRENT_TIMESTAMP());
	SELECT `Id` INTO `uid` FROM `users` WHERE `LoginId`=`name`;
	SELECT MAX(`Id`)+1 INTO `aid` FROM `avatar` WHERE `ServerId`=`sid`;
	IF `aid` IS NULL THEN
	SET `aid`=sid*1000000+1;
	END IF;
	INSERT IGNORE INTO `avatar` (`Id`, `AvatarId`, `UserId`, `ServerId`, `Name`, `CreateDate`, `LastLogin`, `IsDeleted`, `IsGenerate`, `GM`, `ForbidEndTime`) VALUES (`aid`, `aid`, `uid`, `sid`, `name`, CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(), 0, 1, 0, '2000-01-01 00:00:00');
	SELECT Id INTO `aid` FROM `avatar` WHERE `ServerId`=`sid` and `UserId`=`uid`;
	SELECT `aid` as `AvatarId`,`uid` as `UserId`;
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
