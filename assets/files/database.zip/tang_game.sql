/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50731
 Source Host           : localhost:3306
 Source Schema         : tang_game

 Target Server Type    : MySQL
 Target Server Version : 50731
 File Encoding         : 65001

 Date: 04/02/2024 16:51:02
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for achievement
-- ----------------------------
DROP TABLE IF EXISTS `achievement`;
CREATE TABLE `achievement`  (
  `Id` int(11) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `AllCountInfo` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `ix_achievement_avatarId`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for activityitemcomposite
-- ----------------------------
DROP TABLE IF EXISTS `activityitemcomposite`;
CREATE TABLE `activityitemcomposite`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `NumLog` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `LastCompositeTime` datetime NULL DEFAULT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `ThanksgivingAvatar_Index`(`ActivityId`, `AvatarId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 302 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for activitylimittask
-- ----------------------------
DROP TABLE IF EXISTS `activitylimittask`;
CREATE TABLE `activitylimittask`  (
  `Id` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `TaskType` int(11) NOT NULL,
  `Value` bigint(255) NULL DEFAULT NULL,
  `GroupId` int(11) NULL DEFAULT NULL,
  `ReceivedTaskIds` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ModifiedDate` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`Id`, `AvatarId`, `TaskType`) USING BTREE,
  INDEX `ix_activitylimittask_id_avatarId`(`Id`, `AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for activityrecharge
-- ----------------------------
DROP TABLE IF EXISTS `activityrecharge`;
CREATE TABLE `activityrecharge`  (
  `Id` bigint(20) NOT NULL,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `ShowPackId` int(11) NULL DEFAULT NULL COMMENT '展示礼包id',
  `DateStart` datetime NULL DEFAULT NULL COMMENT '活动开启时间',
  `DateEnd` datetime NULL DEFAULT NULL COMMENT '活动结束时间',
  `ResetTime` datetime NULL DEFAULT NULL COMMENT '重置',
  `Count` int(11) NULL DEFAULT NULL COMMENT '活动期间重置天数',
  `Type` int(11) NULL DEFAULT NULL,
  `BuyTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `ServerId_AvatarId`(`ServerId`, `AvatarId`) USING BTREE,
  INDEX `ix_activityrecharge_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for activityrecharge_backups
-- ----------------------------
DROP TABLE IF EXISTS `activityrecharge_backups`;
CREATE TABLE `activityrecharge_backups`  (
  `Id` bigint(20) NOT NULL,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `ShowPackId` int(11) NULL DEFAULT NULL COMMENT '展示礼包id',
  `DateStart` datetime NULL DEFAULT NULL COMMENT '活动开启时间',
  `DateEnd` datetime NULL DEFAULT NULL COMMENT '活动结束时间',
  `ResetTime` datetime NULL DEFAULT NULL COMMENT '重置',
  `Count` int(11) NULL DEFAULT NULL COMMENT '活动期间重置天数',
  `Type` int(11) NULL DEFAULT NULL,
  `BuyTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `ServerId_AvatarId`(`ServerId`, `AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for activitytask
-- ----------------------------
DROP TABLE IF EXISTS `activitytask`;
CREATE TABLE `activitytask`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `ActivityId` int(11) NULL DEFAULT NULL,
  `TaskId` int(11) NULL DEFAULT NULL,
  `TaskProgress` bigint(20) NULL DEFAULT NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `TaskStatus` int(11) NULL DEFAULT NULL,
  `Days` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `ix_activitytask_key`(`AvatarId`, `ActivityId`, `TaskId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 28289 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for assignment
-- ----------------------------
DROP TABLE IF EXISTS `assignment`;
CREATE TABLE `assignment`  (
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `ServerId` int(20) NULL DEFAULT NULL,
  `AssignmentId` int(11) NULL DEFAULT NULL COMMENT '任务id',
  `AssignmentType` int(11) NULL DEFAULT NULL COMMENT '任务类型',
  `SmallType` int(11) NULL DEFAULT NULL,
  `Status` tinyint(4) NULL DEFAULT NULL COMMENT '任务状态',
  `Value` double NULL DEFAULT NULL COMMENT '任务进度',
  `MaxValue` double NULL DEFAULT NULL,
  `Id` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `ix_assignment_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for assignmentprogress
-- ----------------------------
DROP TABLE IF EXISTS `assignmentprogress`;
CREATE TABLE `assignmentprogress`  (
  `Id` int(11) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `Type` int(11) NOT NULL,
  `ProId` int(11) NULL DEFAULT NULL,
  `Count` int(11) NULL DEFAULT NULL,
  `MaxCount` int(11) NULL DEFAULT NULL,
  `PrizeGet` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `Step` int(11) NULL DEFAULT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`, `ServerId`, `Type`) USING BTREE,
  INDEX `avatarid`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatar_csm
-- ----------------------------
DROP TABLE IF EXISTS `avatar_csm`;
CREATE TABLE `avatar_csm`  (
  `AvatarId` bigint(20) NOT NULL,
  `CanBaiTimes` int(11) NULL DEFAULT NULL,
  `LastCanBaiTime` bigint(20) NULL DEFAULT NULL,
  `NextCanBaiTime` bigint(11) NULL DEFAULT NULL,
  `LeftShenJi` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `MoBais` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatar_gatecityv2
-- ----------------------------
DROP TABLE IF EXISTS `avatar_gatecityv2`;
CREATE TABLE `avatar_gatecityv2`  (
  `AvatarId` bigint(20) NOT NULL,
  `Id` int(11) NOT NULL,
  `Lv` int(11) NULL DEFAULT NULL,
  `FanRongScore` bigint(20) NULL DEFAULT NULL,
  `GoldUpTimes` int(11) NULL DEFAULT NULL,
  `WaitAppraise` bigint(20) NULL DEFAULT NULL,
  `WaitPrestige` bigint(20) NULL DEFAULT NULL,
  `MakedMinutes` bigint(20) NULL DEFAULT NULL,
  `CalcStartTime` bigint(20) NULL DEFAULT NULL,
  `AppraisePropId` int(11) NULL DEFAULT NULL,
  `Profession` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`, `Id`) USING BTREE,
  INDEX `ix_gatecityv2_avatarid`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatar_gatenodev2
-- ----------------------------
DROP TABLE IF EXISTS `avatar_gatenodev2`;
CREATE TABLE `avatar_gatenodev2`  (
  `AvatarId` bigint(20) NOT NULL,
  `GateId` int(11) NULL DEFAULT NULL,
  `Node` int(11) NULL DEFAULT NULL,
  `Step` int(11) NULL DEFAULT NULL,
  `CarriageType` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatar_gatev2
-- ----------------------------
DROP TABLE IF EXISTS `avatar_gatev2`;
CREATE TABLE `avatar_gatev2`  (
  `AvatarId` bigint(20) NOT NULL,
  `TalksCaiLi` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `DeathHeros` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ReHerosTimes` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `Events` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `NextResetTime` datetime NULL DEFAULT NULL,
  `FanRongNextResetTime` datetime NULL DEFAULT NULL,
  `FanRongTimes` int(11) NULL DEFAULT NULL,
  `ReceivedStageId` int(11) NULL DEFAULT NULL,
  `WaterCarriageId` int(11) NULL DEFAULT NULL,
  `LandCarriageId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatar_herosdispatchv2
-- ----------------------------
DROP TABLE IF EXISTS `avatar_herosdispatchv2`;
CREATE TABLE `avatar_herosdispatchv2`  (
  `AvatarId` bigint(20) NOT NULL,
  `DispatchHeros` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatar_herosv2
-- ----------------------------
DROP TABLE IF EXISTS `avatar_herosv2`;
CREATE TABLE `avatar_herosv2`  (
  `AvatarId` bigint(20) NOT NULL,
  `Id` int(11) NOT NULL,
  `Lv` int(11) NULL DEFAULT NULL,
  `StudyLv` int(11) NULL DEFAULT NULL,
  `StarLv` int(11) NULL DEFAULT NULL,
  `PetId` int(11) NULL DEFAULT NULL,
  `Quality` int(11) NULL DEFAULT NULL,
  `Profession` int(11) NULL DEFAULT NULL,
  `BaseAbility` int(11) NULL DEFAULT NULL,
  `WearSkinId` int(11) NULL DEFAULT NULL,
  `Skins` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `Skills` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `Halos` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ItemCaiLi` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `OtherCaiLi` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `TaoLi` bigint(20) NULL DEFAULT NULL,
  `IsDeleted` tinyint(1) NULL DEFAULT NULL,
  `IsShared` tinyint(1) NULL DEFAULT NULL COMMENT '是否已分享',
  PRIMARY KEY (`AvatarId`, `Id`) USING BTREE,
  INDEX `ix_avatar_heros_avatarid`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatar_share
-- ----------------------------
DROP TABLE IF EXISTS `avatar_share`;
CREATE TABLE `avatar_share`  (
  `AvatarId` bigint(20) NOT NULL,
  `Date` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `SharedNum` bigint(20) NULL DEFAULT NULL,
  `ShareTime` int(11) NOT NULL,
  `InvitedNum` bigint(20) NULL DEFAULT NULL,
  `InviteTime` int(11) NOT NULL,
  `FriendSharedNum` bigint(20) NULL DEFAULT NULL,
  `FriendShareTime` int(11) NOT NULL,
  `IsCollected` tinyint(1) NULL DEFAULT NULL,
  `Rec1` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `Rec2` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `Rec3` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarbank
-- ----------------------------
DROP TABLE IF EXISTS `avatarbank`;
CREATE TABLE `avatarbank`  (
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `Level` int(11) NULL DEFAULT NULL,
  `Growth` int(11) NULL DEFAULT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `GrowthTimes` int(11) NULL DEFAULT NULL,
  `Addition` int(11) NULL DEFAULT NULL,
  `EndTime` datetime NULL DEFAULT NULL,
  `StartTime` datetime NULL DEFAULT NULL,
  `Count` double NULL DEFAULT 0,
  `MaxCount` double NULL DEFAULT 0,
  `GrowthUpdate` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `ix_avatarbank_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarbase
-- ----------------------------
DROP TABLE IF EXISTS `avatarbase`;
CREATE TABLE `avatarbase`  (
  `Id` bigint(20) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `UserId` bigint(20) NOT NULL COMMENT '所属玩家Id',
  `ServerId` int(11) NOT NULL COMMENT '所属服务器Id',
  `Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '角色名称',
  `Sex` int(11) NULL DEFAULT NULL COMMENT '性别',
  `Level` int(11) NULL DEFAULT NULL COMMENT '等级',
  `VipLevel` int(11) NULL DEFAULT NULL COMMENT 'vip等级',
  `CreateDate` datetime NULL DEFAULT NULL COMMENT '角色创建时间',
  `AddressId` int(11) NULL DEFAULT NULL COMMENT '地址ID ',
  `AddressChangeState` tinyint(4) NULL DEFAULT NULL COMMENT '地址修改状态',
  `Image` int(11) NULL DEFAULT NULL COMMENT '玩家形象',
  `ImageIdList` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '已解锁形象ID列表',
  `HeadFrameId` int(11) NULL DEFAULT NULL COMMENT '当前穿戴头像框ID',
  `HeadFrameIdDic` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '已解锁头像框ID列表 key 头像框ID value 过期时间戳',
  `HeadId` int(11) NULL DEFAULT NULL COMMENT '当前穿戴头像ID',
  `HeadIdList` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '已解锁头像ID列表',
  `TitleId` int(11) NULL DEFAULT NULL COMMENT '当前穿戴称号ID',
  `TitleIdDic` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '已解锁称号ID列表 key 称号Id value 过期时间戳',
  `FashionId` int(11) NULL DEFAULT NULL COMMENT '当前穿戴时装ID',
  `FashionIdDic` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '已解锁时装 key 时装ID value 等级',
  `PlotLevel` int(11) NULL DEFAULT NULL,
  `GM` int(11) NULL DEFAULT NULL,
  `DefHead` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `ix_avatarbase_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarbeauties
-- ----------------------------
DROP TABLE IF EXISTS `avatarbeauties`;
CREATE TABLE `avatarbeauties`  (
  `AvatarId` bigint(20) NOT NULL,
  `Id` int(11) NOT NULL,
  `TitleLv` int(11) NULL DEFAULT NULL,
  `StarLv` int(11) NULL DEFAULT NULL,
  `TotalQinMi` int(11) NULL DEFAULT NULL,
  `TotalMeiLi` int(11) NULL DEFAULT NULL,
  `RewardQinMi` int(11) NULL DEFAULT NULL,
  `RewardMeiLi` int(11) NULL DEFAULT NULL,
  `ItemQinMi` int(11) NULL DEFAULT 0 COMMENT '通过道具获得的亲密度',
  `ItemMeiLi` int(11) NULL DEFAULT 0 COMMENT '通过道具获得的魅力值',
  `Fate` int(11) NULL DEFAULT NULL,
  `ChuYouTimes` int(11) NULL DEFAULT NULL,
  `MuYuTimes` int(11) NULL DEFAULT NULL,
  `WearSkinId` int(11) NULL DEFAULT NULL,
  `TotalKids` int(11) NULL DEFAULT NULL,
  `MarryTime` int(11) NULL DEFAULT NULL,
  `Quality` int(11) NULL DEFAULT NULL,
  `Profession` int(11) NULL DEFAULT NULL,
  `Skins` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `FateSkills` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ShopSkills` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `IsDeleted` tinyint(1) NULL DEFAULT NULL,
  `IsShared` tinyint(1) NULL DEFAULT NULL COMMENT '是否已分享',
  PRIMARY KEY (`AvatarId`, `Id`) USING BTREE,
  INDEX `ix_avatarbeauties_avatarid`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarbeautiesbase
-- ----------------------------
DROP TABLE IF EXISTS `avatarbeautiesbase`;
CREATE TABLE `avatarbeautiesbase`  (
  `AvatarId` bigint(20) NOT NULL COMMENT '玩家Id',
  `ChuanHuanKidTimes` bigint(20) NULL DEFAULT NULL,
  `MustTwinsNum` int(11) NOT NULL,
  `EnergyNum` int(11) NOT NULL,
  `EnergyStartTime` bigint(20) NULL DEFAULT NULL,
  `FavorDic` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `AssignCHBeautyIds` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `DispatchBeauties` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `TeQuanTwinsNextTime` datetime NULL DEFAULT NULL,
  `TeQuanTwinsUseTimes` int(11) NOT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarbeautiestarget
-- ----------------------------
DROP TABLE IF EXISTS `avatarbeautiestarget`;
CREATE TABLE `avatarbeautiestarget`  (
  `Id` bigint(20) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `SmallType` int(11) NULL DEFAULT NULL,
  `Status` int(11) NULL DEFAULT NULL,
  `Value` double NULL DEFAULT NULL,
  `MaxValue` double NULL DEFAULT NULL,
  PRIMARY KEY (`Id`, `AvatarId`) USING BTREE,
  UNIQUE INDEX `ix_Id_AvatarId_key`(`Id`, `AvatarId`) USING BTREE,
  INDEX `ix_AvatarId_Key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarcolddata
-- ----------------------------
DROP TABLE IF EXISTS `avatarcolddata`;
CREATE TABLE `avatarcolddata`  (
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `MaxWaitRewardId` int(11) NULL DEFAULT NULL COMMENT '最大奖励id',
  `WaitRewardDic` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '等待处理的奖励',
  `GuildId` int(11) NULL DEFAULT 0 COMMENT '商会ID',
  `AnnounceTime` datetime NULL DEFAULT NULL COMMENT '公告时间',
  `LeaveGuildTime` datetime NULL DEFAULT NULL COMMENT '最后一次离开商会的时间',
  `RequestGuildIds` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '申请入会的数组',
  `DeviceType` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `DeviceOS` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `DeviceVer` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `DeviceID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `IsOperation` smallint(6) NULL DEFAULT NULL,
  `GuideId` int(11) NULL DEFAULT NULL,
  `RegisterIp` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `MyProperty` int(11) NULL DEFAULT NULL,
  `LoginIp` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ForbidEndTime` datetime NULL DEFAULT NULL,
  `IsRemove` int(11) NULL DEFAULT NULL,
  `StoryId` int(11) NULL DEFAULT 0,
  `PlatformID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `SmallPlatformID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Language` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `SessionId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `AppId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `AppVersion` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `OSLanguage` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `AccountId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `HadGuideGuild` int(11) NULL DEFAULT 0,
  `NonstopLoginDayCount` int(11) NULL DEFAULT NULL,
  `CVer` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `InvitationCode` bigint(20) NULL DEFAULT 0,
  `CommunityReceivedIds` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `ix_avatarcolddata_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarcurrency
-- ----------------------------
DROP TABLE IF EXISTS `avatarcurrency`;
CREATE TABLE `avatarcurrency`  (
  `Id` bigint(20) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL COMMENT '所属服务器Id',
  `Experience` bigint(20) NULL DEFAULT NULL COMMENT '角色当前阅历',
  `Money` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '角色通宝',
  `Prestige` bigint(20) NULL DEFAULT NULL COMMENT '当前声望',
  `Gold` bigint(20) NULL DEFAULT NULL COMMENT '当前金珠',
  `JiaoZi` bigint(20) NULL DEFAULT NULL COMMENT '客栈交子',
  `ChenNiang` bigint(20) NULL DEFAULT NULL COMMENT '乔迁陈酿',
  `ShangZhanBi` bigint(20) NULL DEFAULT NULL COMMENT '商战币',
  `ShangHuiGongXian` bigint(20) NULL DEFAULT NULL COMMENT '商会贡献',
  `YanHuiBi` bigint(20) NULL DEFAULT NULL COMMENT '宴会币',
  `ShouLieJiFen` bigint(20) NULL DEFAULT NULL COMMENT '狩猎积分',
  `XunLingYe` bigint(20) NULL DEFAULT NULL,
  `TotalGold` bigint(20) NULL DEFAULT NULL,
  `StoresConsumeGold` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `ix_avatarcurrency_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avataremail
-- ----------------------------
DROP TABLE IF EXISTS `avataremail`;
CREATE TABLE `avataremail`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NOT NULL,
  `EmailId` bigint(20) NULL DEFAULT NULL,
  `EmailType` bigint(20) NULL DEFAULT NULL,
  `TemplateId` int(11) NULL DEFAULT NULL,
  `Title` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `Content` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `Params` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `Items` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `STime` datetime NULL DEFAULT NULL,
  `ETime` datetime NULL DEFAULT NULL,
  `State` int(11) NULL DEFAULT NULL,
  `SourceId` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `AvatarId_EmailId_Index`(`AvatarId`, `EmailId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 105346 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarfirstpack
-- ----------------------------
DROP TABLE IF EXISTS `avatarfirstpack`;
CREATE TABLE `avatarfirstpack`  (
  `Id` bigint(20) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `CreateTime` datetime NULL DEFAULT NULL,
  `EndTime` datetime NULL DEFAULT NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  `ReceiveInfo` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `FirstPack` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `ix_avatarfirstpack_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatargoldstores
-- ----------------------------
DROP TABLE IF EXISTS `avatargoldstores`;
CREATE TABLE `avatargoldstores`  (
  `Id` int(11) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `NextResetTime` datetime NULL DEFAULT NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  `BuyInfos` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarhotdata
-- ----------------------------
DROP TABLE IF EXISTS `avatarhotdata`;
CREATE TABLE `avatarhotdata`  (
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `LoginStatus` tinyint(4) NULL DEFAULT NULL COMMENT '玩家登录状态',
  `LastLoginTime` datetime NULL DEFAULT NULL COMMENT '上一次登录时间',
  `LastOfflineTime` datetime NULL DEFAULT NULL COMMENT '最后离线时间',
  `IsReceive` tinyint(4) NULL DEFAULT NULL COMMENT '每日奖励领取状态',
  `ResetTime` datetime NULL DEFAULT NULL COMMENT '每日数据重置时间',
  `EarnSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '当前赚速',
  `SendMoneyTimes` int(11) NULL DEFAULT NULL,
  `ReceiveGradeIds` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `FinallyTime` datetime NULL DEFAULT NULL,
  `LoginTimes` int(11) NULL DEFAULT NULL,
  `OnLineTime` bigint(20) NULL DEFAULT NULL,
  `DailyOnline` bigint(20) NULL DEFAULT NULL,
  `TotalEarnSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `LastGetEmailTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `ix_avatarhotdata_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarillustrated
-- ----------------------------
DROP TABLE IF EXISTS `avatarillustrated`;
CREATE TABLE `avatarillustrated`  (
  `Id` bigint(20) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `HaloInfoDic` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `HaloIds` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ReceiveIdList` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `Aggregate` int(11) NULL DEFAULT NULL,
  `IllustartedDic` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `ix_avatarillustrated_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarinlaws
-- ----------------------------
DROP TABLE IF EXISTS `avatarinlaws`;
CREATE TABLE `avatarinlaws`  (
  `Id` bigint(20) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `InLawsAvatarId` bigint(20) NOT NULL COMMENT '亲家Id',
  `UpdateTime` datetime NULL DEFAULT NULL,
  `IsInLaws` tinyint(4) NULL DEFAULT NULL,
  `MarriageDic` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '已联姻子嗣',
  `MarriageTimes` int(11) NULL DEFAULT NULL COMMENT '联姻次数',
  `SentGift` tinyint(4) NULL DEFAULT NULL COMMENT '送礼状态 0 未送 1 已送',
  `ReceivedGift` tinyint(4) NULL DEFAULT NULL COMMENT '收礼状态 0 不可收 1 可收 2 已领取',
  PRIMARY KEY (`AvatarId`, `InLawsAvatarId`) USING BTREE,
  INDEX `ix_avatarinlaws_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarinlawsletter
-- ----------------------------
DROP TABLE IF EXISTS `avatarinlawsletter`;
CREATE TABLE `avatarinlawsletter`  (
  `Id` bigint(20) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `InLawsAvatarId` bigint(20) NOT NULL COMMENT '亲家id',
  `CreateTime` datetime NULL DEFAULT NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  `IsRead` tinyint(4) NULL DEFAULT NULL COMMENT '是否已读',
  `Content` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '书信内容',
  `LetterId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`, `InLawsAvatarId`) USING BTREE,
  INDEX `ix_avatarinlawsletter_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarkid
-- ----------------------------
DROP TABLE IF EXISTS `avatarkid`;
CREATE TABLE `avatarkid`  (
  `Id` bigint(20) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `BeautyId` int(11) NULL DEFAULT NULL,
  `PlaceId` int(11) NULL DEFAULT NULL,
  `Twins` tinyint(4) NULL DEFAULT 0,
  `Sex` int(11) NULL DEFAULT NULL,
  `KidName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Job` int(11) NULL DEFAULT NULL,
  `Quality` int(11) NULL DEFAULT NULL,
  `WorkId` int(11) NULL DEFAULT NULL,
  `AdultStatus` tinyint(4) NULL DEFAULT NULL,
  `MarriageStatus` int(11) NULL DEFAULT NULL,
  `ProposalId` int(11) NULL DEFAULT 0,
  `HeroId` int(11) NULL DEFAULT NULL,
  `ShopId` int(11) NULL DEFAULT NULL,
  `UpdateTime` datetime(2) NULL DEFAULT NULL,
  `ProposalTime` datetime(2) NULL DEFAULT NULL,
  `MarriageTime` datetime(2) NULL DEFAULT NULL,
  `Addtion` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `AdultEarnSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `FinalEarnSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `AdultBaseEarnSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `KidEarnSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `SumEarnSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `MarriageAvatarId` bigint(20) NULL DEFAULT 0,
  `MarriageKidId` int(11) NULL DEFAULT NULL,
  `MarriageEarnSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `MarriageAddItem` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `TaoLi` bigint(20) NULL DEFAULT NULL,
  UNIQUE INDEX `ix_id_avatarId`(`Id`, `AvatarId`) USING BTREE,
  INDEX `ix_avatarkid_key`(`AvatarId`) USING BTREE,
  INDEX `ix_MarriageAvatarId`(`MarriageAvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarkidbase
-- ----------------------------
DROP TABLE IF EXISTS `avatarkidbase`;
CREATE TABLE `avatarkidbase`  (
  `Id` bigint(20) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL COMMENT '子嗣活力值上限',
  `MaxSonVitality` int(11) NULL DEFAULT NULL,
  `InLawsSendGiftTimes` int(11) NULL DEFAULT NULL COMMENT '当日亲家剩余送礼次数',
  `InLawsReceiveGiftTimes` int(11) NULL DEFAULT NULL COMMENT '当日亲家剩余收礼次数',
  `MaxKid` int(11) NULL DEFAULT NULL,
  `KidRefuseProposalSwitch` tinyint(4) NULL DEFAULT NULL COMMENT '子嗣拒绝联姻开关',
  `MaxSpeedKid` int(11) NULL DEFAULT NULL COMMENT '最高赚速子嗣id',
  `KidMaxSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `MaxSpeedUpdateTime` datetime NULL DEFAULT NULL,
  `MyKidRank` int(11) NULL DEFAULT NULL COMMENT '子嗣最高排名',
  `KidRankVer` int(11) NULL DEFAULT NULL,
  `IsNewproposals` tinyint(4) NULL DEFAULT NULL,
  `IsNewWorkKids` tinyint(4) NULL DEFAULT NULL,
  `NewWorkKids` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `IsNewInLaws` tinyint(4) NULL DEFAULT NULL COMMENT '是否有新亲家通知',
  `InLawUnlock` tinyint(4) NULL DEFAULT NULL,
  `FakeMarriageName` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `ix_avatarkidbase_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarkidplace
-- ----------------------------
DROP TABLE IF EXISTS `avatarkidplace`;
CREATE TABLE `avatarkidplace`  (
  `Id` bigint(20) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `PlaceId` int(11) NOT NULL COMMENT '槽位Id',
  `KidList` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '槽位子嗣列表',
  `CultureMoney` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '培养消耗',
  `CultureRewExperience` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '培养阅历奖励',
  `EnergyValue` int(11) NULL DEFAULT NULL COMMENT '剩余活力值',
  `LastConsumeTime` datetime NULL DEFAULT NULL COMMENT '上一次消耗时间',
  `Quality` int(11) NULL DEFAULT NULL,
  `EndTime` datetime NULL DEFAULT NULL,
  `HeroId` int(11) NULL DEFAULT NULL,
  `ShopId` int(11) NULL DEFAULT NULL,
  `ZhuaZhouTimes` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`, `PlaceId`) USING BTREE,
  INDEX `ix_avatarkidplace_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarpet
-- ----------------------------
DROP TABLE IF EXISTS `avatarpet`;
CREATE TABLE `avatarpet`  (
  `Id` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `ModelId` int(11) NULL DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Level` int(11) NULL DEFAULT NULL,
  `Quality` int(11) NULL DEFAULT NULL,
  `QualitySmall` int(11) NULL DEFAULT NULL,
  `QualityLevel` int(11) NULL DEFAULT NULL,
  `Aptitude` int(11) NULL DEFAULT NULL,
  `HeroId` int(11) NULL DEFAULT NULL,
  `LastReplaceTime` bigint(20) NULL DEFAULT NULL,
  `ReplaceNum` int(11) NULL DEFAULT NULL,
  `Skills` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `SkillRefreshLogs` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `Awakening` int(11) NULL DEFAULT NULL,
  `PropertyPool` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`Id`, `AvatarId`) USING BTREE,
  INDEX `ix_avatarkid_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarpoppack
-- ----------------------------
DROP TABLE IF EXISTS `avatarpoppack`;
CREATE TABLE `avatarpoppack`  (
  `Id` bigint(11) NOT NULL,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `PopPackId` int(11) NULL DEFAULT NULL,
  `GroupId` int(11) NULL DEFAULT NULL,
  `StatrTime` datetime NULL DEFAULT NULL,
  `EndTime` datetime NULL DEFAULT NULL,
  `NextConditionTime` datetime NULL DEFAULT NULL,
  `IsDispose` tinyint(4) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `ix_avatarpoppack_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarprivilegecard
-- ----------------------------
DROP TABLE IF EXISTS `avatarprivilegecard`;
CREATE TABLE `avatarprivilegecard`  (
  `AvatarId` bigint(20) NOT NULL,
  `CardsInfo` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarrank
-- ----------------------------
DROP TABLE IF EXISTS `avatarrank`;
CREATE TABLE `avatarrank`  (
  `AvatarId` bigint(20) NOT NULL,
  `SMoBai` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `CrossSMoBai` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarrechargebase
-- ----------------------------
DROP TABLE IF EXISTS `avatarrechargebase`;
CREATE TABLE `avatarrechargebase`  (
  `Id` bigint(20) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `RMB` int(11) NULL DEFAULT NULL,
  `MaxRMB` int(11) NULL DEFAULT NULL,
  `Times` int(11) NULL DEFAULT NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  `NextResetTime` datetime NULL DEFAULT NULL,
  `FirstInfo` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `LimitBuyInfo` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '礼包限购信息',
  `PopPackInfo` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ToDayRMB` int(11) NULL DEFAULT NULL,
  `TeHuiStatus` int(11) NULL DEFAULT NULL,
  `ZhunGuiInfo` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Dollar` float NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `ix_avatarrechargebase_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarroutebase
-- ----------------------------
DROP TABLE IF EXISTS `avatarroutebase`;
CREATE TABLE `avatarroutebase`  (
  `Id` bigint(20) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `PortLv` int(11) NULL DEFAULT NULL COMMENT '市舶司等级',
  `PortBeginTime` datetime NULL DEFAULT NULL COMMENT '市舶司收益开始时间',
  `DockyardLv` int(11) NULL DEFAULT NULL COMMENT '造船厂等级',
  `DockyardTimes` int(11) NULL DEFAULT NULL COMMENT '造船次数',
  `ShipLv` int(11) NULL DEFAULT NULL COMMENT '船只等级',
  `ShipName` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '船只名称',
  `RecruitLv` int(11) NULL DEFAULT NULL COMMENT '招募等级',
  `RecruitRate` int(11) NULL DEFAULT NULL COMMENT '招募进度',
  `Recruit` int(11) NULL DEFAULT NULL COMMENT '每次招募进度',
  `RecruitTimes` int(11) NULL DEFAULT NULL COMMENT '剩余招募次数',
  `RecruitRecoverTime` datetime NULL DEFAULT NULL COMMENT '上一次恢复招募次数时间',
  `RecruitPrice` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '招募消耗',
  `RecruitExp` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '招募奖励',
  `ToDayTimes` int(11) NULL DEFAULT NULL COMMENT '当日开拓航线次数',
  `ShipRouteList` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '待出航航线列表',
  `RecruitList` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '招募等级',
  `Score` bigint(20) NULL DEFAULT NULL,
  `RankTime` bigint(20) NULL DEFAULT NULL,
  `SetSailInfos` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `TotalScore` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `ix_avatarroutebase_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarscore
-- ----------------------------
DROP TABLE IF EXISTS `avatarscore`;
CREATE TABLE `avatarscore`  (
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `Type` int(11) NOT NULL,
  `TotalValue` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `MaxValue` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`, `Type`) USING BTREE,
  INDEX `ix_avatarscore_avatarid`(`AvatarId`) USING BTREE,
  INDEX `ix_avatarscore_serverid_avatarid`(`ServerId`, `AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarship
-- ----------------------------
DROP TABLE IF EXISTS `avatarship`;
CREATE TABLE `avatarship`  (
  `Id` int(11) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `ShIpId` int(11) NOT NULL,
  `ShipsLv` int(11) NULL DEFAULT NULL,
  `ShipsName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Status` int(11) NULL DEFAULT NULL,
  `RecruitLv` int(11) NULL DEFAULT NULL,
  `TizhiAdd` int(11) NULL DEFAULT NULL,
  `MoulueAdd` int(11) NULL DEFAULT NULL,
  `SailAdd` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`, `ShIpId`) USING BTREE,
  INDEX `ix_avatarship_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarshiproute
-- ----------------------------
DROP TABLE IF EXISTS `avatarshiproute`;
CREATE TABLE `avatarshiproute`  (
  `Id` int(11) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `RouteId` int(11) NOT NULL COMMENT '航线id',
  `RouteTimes` int(11) NULL DEFAULT NULL COMMENT '出航次数',
  `DevelopsTimes` int(11) NULL DEFAULT NULL COMMENT '开拓次数',
  `Quality` int(11) NULL DEFAULT NULL COMMENT '当前品质',
  `Status` int(11) NULL DEFAULT NULL COMMENT '航线状态',
  `ReceiveQualityId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`, `RouteId`) USING BTREE,
  INDEX `ix_avatarshiproute_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarshop
-- ----------------------------
DROP TABLE IF EXISTS `avatarshop`;
CREATE TABLE `avatarshop`  (
  `Id` int(11) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `ShopId` int(11) NOT NULL,
  `ShopName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ShopType` int(11) NULL DEFAULT NULL,
  `ShopLv` int(11) NULL DEFAULT NULL,
  `Partner` int(11) NULL DEFAULT NULL,
  `BuddyEarnSpeed` int(11) NULL DEFAULT NULL,
  `GoodsList` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `GoodsLv` int(11) NULL DEFAULT NULL,
  `BuildStatus` int(11) NULL DEFAULT NULL,
  `ShopAdd` double NULL DEFAULT NULL,
  `Beautys` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Heros` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `EarnSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `TotalEarnSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `KidEarnSpeedAdd` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `EventId` int(11) NULL DEFAULT NULL,
  `NextEventTime` datetime NULL DEFAULT NULL,
  `IsChangeName` int(11) NULL DEFAULT NULL,
  `WorkPrice` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`, `ShopId`) USING BTREE,
  INDEX `ix_avatarshop_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarshopbase
-- ----------------------------
DROP TABLE IF EXISTS `avatarshopbase`;
CREATE TABLE `avatarshopbase`  (
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `EasterEggs` int(11) NULL DEFAULT NULL,
  `CamelUpdateTime` datetime NULL DEFAULT NULL,
  `CamelBeginTime` datetime NULL DEFAULT NULL,
  `CamelId` int(11) NULL DEFAULT NULL,
  `CamelStatus` int(11) NULL DEFAULT NULL,
  `ShopGoodsDic` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ShopEggEvents` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `NextTriggerTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `ix_avatarshopbase_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarshopmerchant
-- ----------------------------
DROP TABLE IF EXISTS `avatarshopmerchant`;
CREATE TABLE `avatarshopmerchant`  (
  `Id` int(11) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `NextResetTime` datetime NULL DEFAULT NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  `BuyTimes` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `ix_avatarshopmershant_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatartitle
-- ----------------------------
DROP TABLE IF EXISTS `avatartitle`;
CREATE TABLE `avatartitle`  (
  `Id` bigint(20) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `TitleId` int(11) NULL DEFAULT NULL,
  `GetTime` bigint(20) NULL DEFAULT NULL,
  `OverTime` bigint(20) NULL DEFAULT NULL,
  `TitleState` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`, `Id`) USING BTREE,
  INDEX `ServerId`(`ServerId`) USING BTREE,
  INDEX `AvatarId_ServerId`(`AvatarId`, `ServerId`) USING BTREE,
  INDEX `ix_avatartitle_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatartravel
-- ----------------------------
DROP TABLE IF EXISTS `avatartravel`;
CREATE TABLE `avatartravel`  (
  `Id` bigint(20) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `TravelMaxPower` int(11) NULL DEFAULT NULL,
  `TravelPower` int(11) NULL DEFAULT NULL,
  `LastConsumeTime` datetime NULL DEFAULT NULL,
  `EventList` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `TravelTimes` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `ix_avatartravel_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarvip
-- ----------------------------
DROP TABLE IF EXISTS `avatarvip`;
CREATE TABLE `avatarvip`  (
  `AvatarId` bigint(20) NOT NULL,
  `VIPExp` int(11) NULL DEFAULT NULL,
  `VIPGifts` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarvisit
-- ----------------------------
DROP TABLE IF EXISTS `avatarvisit`;
CREATE TABLE `avatarvisit`  (
  `AvatarId` bigint(20) NOT NULL,
  `EarnAddRate` int(11) NULL DEFAULT NULL,
  `ZanOrGuMeItems` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `FreeZan` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `NextRefreshTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for avatarzanguhistory
-- ----------------------------
DROP TABLE IF EXISTS `avatarzanguhistory`;
CREATE TABLE `avatarzanguhistory`  (
  `Id` int(20) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NOT NULL COMMENT '玩家Id',
  `ServerId` int(11) NULL DEFAULT NULL COMMENT '所属服务器Id',
  `OpAvatarId` bigint(20) NOT NULL COMMENT '来点赞或蛊惑我的玩家Id',
  `OpServerId` int(11) NULL DEFAULT NULL COMMENT '来点赞或蛊惑我的玩家区服',
  `OpTime` bigint(20) NULL DEFAULT NULL COMMENT '来点赞或蛊惑我的玩家操作时间',
  `OpType` int(11) NULL DEFAULT NULL COMMENT '来点赞或蛊惑我的玩家操作类型',
  `AddRate` int(11) NULL DEFAULT NULL COMMENT '来点赞或蛊惑我，对我造成的加成值万分比（点赞为正数，蛊惑为负数）',
  `ExpireTime` bigint(20) NULL DEFAULT NULL COMMENT '过期时间',
  `OpPlayerJson` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `ix_avatarzanguhistory_avatarid`(`AvatarId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 301 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for banquet_cardsv2
-- ----------------------------
DROP TABLE IF EXISTS `banquet_cardsv2`;
CREATE TABLE `banquet_cardsv2`  (
  `Id` bigint(19) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `CardType` int(11) NOT NULL,
  `SourceId` bigint(20) NULL DEFAULT NULL,
  `ExpireTime` bigint(20) NULL DEFAULT NULL,
  `SourceInfo` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `IsUsed` tinyint(1) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`, `AvatarId`) USING BTREE,
  INDEX `ix_banquet_cardsv2_avatarid`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for banquet_popsv2
-- ----------------------------
DROP TABLE IF EXISTS `banquet_popsv2`;
CREATE TABLE `banquet_popsv2`  (
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `IsFakeSeated` tinyint(4) NULL DEFAULT NULL,
  `Pop` bigint(20) NULL DEFAULT NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for banquet_seatsv2
-- ----------------------------
DROP TABLE IF EXISTS `banquet_seatsv2`;
CREATE TABLE `banquet_seatsv2`  (
  `Id` bigint(20) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` bigint(20) NOT NULL,
  `SeatAvatarId` bigint(20) NOT NULL,
  `SeatServerId` int(11) NOT NULL,
  `Type` int(11) NULL DEFAULT NULL,
  `SeatSort` int(11) NOT NULL,
  `SeatTime` bigint(20) NULL DEFAULT NULL,
  `GiftType` int(11) NULL DEFAULT NULL,
  `Pop` int(11) NULL DEFAULT NULL,
  `Coin` int(11) NULL DEFAULT NULL,
  `PopRewards` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `SeatPlayer` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  PRIMARY KEY (`Id`, `ServerId`, `SeatAvatarId`, `SeatSort`) USING BTREE,
  INDEX `ix_banquet_seatsv2_avatarid`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for banquetv2
-- ----------------------------
DROP TABLE IF EXISTS `banquetv2`;
CREATE TABLE `banquetv2`  (
  `Id` bigint(20) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `SettingId` int(11) NULL DEFAULT NULL,
  `Type` int(11) NULL DEFAULT NULL,
  `CardId` bigint(20) NULL DEFAULT NULL,
  `CardInfo` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `STime` bigint(20) NULL DEFAULT NULL,
  `ETime` bigint(20) NULL DEFAULT NULL,
  `IsOver` tinyint(1) NULL DEFAULT NULL,
  `IsChecked` tinyint(1) NULL DEFAULT NULL,
  `SeatNum` int(11) NULL DEFAULT NULL,
  `Pop` int(11) NULL DEFAULT NULL,
  `Coin` int(11) NULL DEFAULT NULL,
  `Player` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `PopRewards` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `NextNPCSeatTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`, `AvatarId`) USING BTREE,
  INDEX `ix_banquetv2_serverid_avatarid`(`ServerId`, `AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for bosswayavatar
-- ----------------------------
DROP TABLE IF EXISTS `bosswayavatar`;
CREATE TABLE `bosswayavatar`  (
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `TotalScore` bigint(20) NULL DEFAULT NULL,
  `IsFinished` tinyint(255) NULL DEFAULT NULL,
  `DailyDate` int(11) NULL DEFAULT NULL,
  `DailyScore` bigint(20) NULL DEFAULT NULL,
  `DailyBossId` int(11) NULL DEFAULT NULL,
  `DailyLeftHp` double(50, 0) NULL DEFAULT NULL,
  `DailyTotalHp` double(50, 0) NULL DEFAULT NULL,
  `DieHeros` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `DieGuildHeros` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `ix_bosswayavatar_serveridavatarid`(`ServerId`, `AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for bosswayserver
-- ----------------------------
DROP TABLE IF EXISTS `bosswayserver`;
CREATE TABLE `bosswayserver`  (
  `ActivityId` int(11) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `BoxItems` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`ServerId`, `ActivityId`) USING BTREE,
  INDEX `ix_bosswayserver_serverid_activityid`(`ServerId`, `ActivityId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for cointoss
-- ----------------------------
DROP TABLE IF EXISTS `cointoss`;
CREATE TABLE `cointoss`  (
  `ActivityId` int(11) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`ActivityId`, `ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for cointossavatar
-- ----------------------------
DROP TABLE IF EXISTS `cointossavatar`;
CREATE TABLE `cointossavatar`  (
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `Score` int(11) NULL DEFAULT NULL,
  `LastScoreTime` datetime NULL DEFAULT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `RankRewardReceive` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ThrowMoneyDic` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `ThrowMoneyReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `TossTaskProgress` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TaskRewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailRewards` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`ActivityId`, `AvatarId`, `ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for day7base
-- ----------------------------
DROP TABLE IF EXISTS `day7base`;
CREATE TABLE `day7base`  (
  `AvatarId` bigint(20) NOT NULL,
  `Scores` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `BoughtGiftPacks` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for day7task
-- ----------------------------
DROP TABLE IF EXISTS `day7task`;
CREATE TABLE `day7task`  (
  `Id` bigint(20) NOT NULL,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `TaskId` int(11) NULL DEFAULT NULL,
  `TaskProgress` bigint(20) NULL DEFAULT NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  `TaskStatus` int(11) NULL DEFAULT NULL,
  `Days` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `ix_day7task_avatarid`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for delguildskill_temp
-- ----------------------------
DROP TABLE IF EXISTS `delguildskill_temp`;
CREATE TABLE `delguildskill_temp`  (
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `SkillType` int(11) NOT NULL DEFAULT 0,
  `SkillLv` int(11) NULL DEFAULT NULL,
  `ShangHuiGongXian` int(11) NULL DEFAULT NULL,
  `XinYi` int(11) NULL DEFAULT NULL,
  `QingYi` int(11) NOT NULL DEFAULT 0
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for demotable
-- ----------------------------
DROP TABLE IF EXISTS `demotable`;
CREATE TABLE `demotable`  (
  `id` int(11) NULL DEFAULT NULL,
  `petId` int(11) NULL DEFAULT NULL,
  `avatarid` bigint(20) NULL DEFAULT NULL,
  `info` varchar(5000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Lv` int(11) NULL DEFAULT NULL,
  `ModelId` int(11) NULL DEFAULT NULL,
  `Aptitude` int(11) NULL DEFAULT NULL,
  `Num` int(11) NULL DEFAULT NULL,
  `NewInfo` varchar(5000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for exchangeactivity
-- ----------------------------
DROP TABLE IF EXISTS `exchangeactivity`;
CREATE TABLE `exchangeactivity`  (
  `ActivityId` int(11) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `BeginTime` datetime NULL DEFAULT NULL,
  `EndTime` datetime NULL DEFAULT NULL,
  `Status` int(11) NULL DEFAULT NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  `Info` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ActivityId`, `ServerId`) USING BTREE,
  INDEX `ix_exchangeactivity_key`(`ActivityId`, `ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for exchangeactivityavatar
-- ----------------------------
DROP TABLE IF EXISTS `exchangeactivityavatar`;
CREATE TABLE `exchangeactivityavatar`  (
  `AvatarId` bigint(20) NOT NULL,
  `ActivityId` int(11) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `Score` int(11) NULL DEFAULT NULL,
  `Exchange` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `EndTime` datetime NULL DEFAULT NULL,
  `Message` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '活动奖励补发信息',
  PRIMARY KEY (`AvatarId`, `ActivityId`, `ServerId`) USING BTREE,
  INDEX `ix_exchangeactivityavatar_key`(`ActivityId`, `ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for fertilizerlog
-- ----------------------------
DROP TABLE IF EXISTS `fertilizerlog`;
CREATE TABLE `fertilizerlog`  (
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `CurScore` bigint(20) NOT NULL,
  `AddScore` bigint(20) NOT NULL,
  `Reward` longtext CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `OpTime` datetime NULL DEFAULT NULL,
  UNIQUE INDEX `FertilizerLog_Index`(`ActivityId`, `AvatarId`, `CurScore`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for fisrttestuser
-- ----------------------------
DROP TABLE IF EXISTS `fisrttestuser`;
CREATE TABLE `fisrttestuser`  (
  `UserId` bigint(20) NOT NULL,
  `HadSendEmail` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`UserId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for forbidlog
-- ----------------------------
DROP TABLE IF EXISTS `forbidlog`;
CREATE TABLE `forbidlog`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `Type` int(11) NULL DEFAULT NULL,
  `Status` int(11) NULL DEFAULT NULL,
  `ForbidTime` bigint(20) NULL DEFAULT NULL,
  `Hours` int(11) NULL DEFAULT NULL,
  `EndTime` bigint(20) NULL DEFAULT NULL,
  `Reason` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `ix_forbidlog_key`(`ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for fund
-- ----------------------------
DROP TABLE IF EXISTS `fund`;
CREATE TABLE `fund`  (
  `AvatarId` bigint(20) NOT NULL,
  `ActivityId` int(11) NOT NULL,
  `IsToll` tinyint(1) NOT NULL,
  `ReceiveFree` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ReceiveToll` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  UNIQUE INDEX `Fund_Index`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for fundtask
-- ----------------------------
DROP TABLE IF EXISTS `fundtask`;
CREATE TABLE `fundtask`  (
  `AvatarId` bigint(20) NOT NULL,
  `ActivityId` int(11) NOT NULL,
  `TaskSmallType` int(11) NOT NULL,
  `Progress` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  UNIQUE INDEX `FundTask_Index`(`AvatarId`, `ActivityId`, `TaskSmallType`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for fundtaskreceivelog
-- ----------------------------
DROP TABLE IF EXISTS `fundtaskreceivelog`;
CREATE TABLE `fundtaskreceivelog`  (
  `AvatarId` bigint(20) NOT NULL,
  `ActivityId` int(11) NOT NULL,
  `TaskId` int(11) NOT NULL,
  `RewardFree` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `RewardToll` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  INDEX `FundTaskReceiveLog_Index`(`AvatarId`, `ActivityId`, `TaskId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guild
-- ----------------------------
DROP TABLE IF EXISTS `guild`;
CREATE TABLE `guild`  (
  `GuildId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `Logo` int(11) NULL DEFAULT NULL,
  `LogoExpire` datetime NULL DEFAULT NULL,
  `OldLogo` int(11) NULL DEFAULT NULL,
  `SpecialLogo` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `Name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ContactInfo` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Declaration` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Announce` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `AnnounceTime` datetime NULL DEFAULT NULL,
  `AutoJoin` tinyint(1) NULL DEFAULT NULL,
  `IsDissolved` tinyint(1) NULL DEFAULT NULL,
  `MemberCount` int(11) NULL DEFAULT NULL,
  `Level` int(11) NULL DEFAULT NULL,
  `FounderId` mediumtext CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `CreateTime` datetime NULL DEFAULT NULL,
  `President` bigint(20) NULL DEFAULT NULL,
  `VicePresident` bigint(20) NULL DEFAULT NULL,
  `LogoUpdateTime` datetime NULL DEFAULT NULL,
  `MemberDic` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `RequsterList` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `Logs` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `BossKillTimes` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`GuildId`, `ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildaltar
-- ----------------------------
DROP TABLE IF EXISTS `guildaltar`;
CREATE TABLE `guildaltar`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ServerId` int(11) NOT NULL,
  `WeekIndex` int(11) NOT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `NextResetDate` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `GuildAltar_Index`(`ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 69 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildaltaravatar
-- ----------------------------
DROP TABLE IF EXISTS `guildaltaravatar`;
CREATE TABLE `guildaltaravatar`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NOT NULL,
  `WeekIndex` int(11) NOT NULL,
  `FightIndex` int(11) NOT NULL,
  `Score` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `LastScoreTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `GuildAltarAvatar_Index`(`AvatarId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 641 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildaltaravatarcolddata
-- ----------------------------
DROP TABLE IF EXISTS `guildaltaravatarcolddata`;
CREATE TABLE `guildaltaravatarcolddata`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NOT NULL,
  `WeekIndex` int(11) NOT NULL,
  `FightBoss` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `BossRewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `RewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `HeroResetTime` datetime NULL DEFAULT NULL,
  `MailBossRewards` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailBossTime` datetime NULL DEFAULT NULL,
  `MailRewards` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `GuildAltarAvatarColdData_Index`(`AvatarId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 500 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildaltaravatarhero
-- ----------------------------
DROP TABLE IF EXISTS `guildaltaravatarhero`;
CREATE TABLE `guildaltaravatarhero`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NOT NULL,
  `HeroId` int(11) NULL DEFAULT NULL,
  `WeekIndex` int(11) NOT NULL,
  `FightTimes` int(11) NULL DEFAULT NULL,
  `BuyFightTimes` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `GuildAltarAvatarHero_Index`(`AvatarId`, `HeroId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 119 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildaltaravatarlog
-- ----------------------------
DROP TABLE IF EXISTS `guildaltaravatarlog`;
CREATE TABLE `guildaltaravatarlog`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NOT NULL,
  `WeekIndex` int(11) NOT NULL,
  `FightIndex` int(11) NOT NULL,
  `GuildId` bigint(20) NOT NULL,
  `HeroId` int(11) NULL DEFAULT NULL,
  `HeroAtk` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `AddScore` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CurScore` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CurBossId` int(11) NULL DEFAULT NULL,
  `TotalBossBlood` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CurBossBlood` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `BossId` int(11) NULL DEFAULT NULL,
  `Damage` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `Reward` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `OpTime` datetime NULL DEFAULT NULL,
  `Reason` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `GuildAltarAvatarLog_Index`(`AvatarId`, `WeekIndex`, `FightIndex`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 211 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildaltarboss
-- ----------------------------
DROP TABLE IF EXISTS `guildaltarboss`;
CREATE TABLE `guildaltarboss`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `WeekIndex` int(11) NOT NULL,
  `GuildId` bigint(20) NOT NULL,
  `Day` int(11) NOT NULL,
  `BossId` int(11) NOT NULL,
  `BossPicId` int(11) NOT NULL,
  `TotalBlood` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CurBlood` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `Killer` bigint(20) NULL DEFAULT NULL,
  `KillTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `GuildAltarBoss_Index`(`GuildId`, `BossPicId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 167 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildbargain
-- ----------------------------
DROP TABLE IF EXISTS `guildbargain`;
CREATE TABLE `guildbargain`  (
  `GuildId` bigint(20) NOT NULL,
  `EndTime` datetime NULL DEFAULT NULL,
  `ItemDic` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `OldPrice` int(11) NULL DEFAULT NULL,
  `CurPrice` int(11) NULL DEFAULT NULL,
  `MaxPerson` int(11) NULL DEFAULT NULL,
  `LogDic` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  PRIMARY KEY (`GuildId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildbuild
-- ----------------------------
DROP TABLE IF EXISTS `guildbuild`;
CREATE TABLE `guildbuild`  (
  `GuildId` bigint(20) NOT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `Progress` int(11) NULL DEFAULT NULL,
  `Logs` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `TodayCtrb` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `SumCtrb` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  PRIMARY KEY (`GuildId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildhotdata
-- ----------------------------
DROP TABLE IF EXISTS `guildhotdata`;
CREATE TABLE `guildhotdata`  (
  `GuildId` bigint(20) NOT NULL,
  `TotalEarnSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TotalEarnSpeedUpdateTime` datetime NOT NULL,
  `HistoryMaxTotalEarnSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `Exp` bigint(20) NULL DEFAULT NULL,
  `Money` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`GuildId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildhouse
-- ----------------------------
DROP TABLE IF EXISTS `guildhouse`;
CREATE TABLE `guildhouse`  (
  `GuildId` bigint(20) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `HeroId` int(11) NOT NULL,
  `HeroProfession` int(11) NOT NULL,
  `HeroAddtion` bigint(20) NOT NULL,
  `HerosKills` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  UNIQUE INDEX `GuildHouse_Index`(`GuildId`, `AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildmember
-- ----------------------------
DROP TABLE IF EXISTS `guildmember`;
CREATE TABLE `guildmember`  (
  `AvatarId` bigint(20) NOT NULL,
  `GuildId` bigint(20) NOT NULL,
  `Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `HeadId` int(11) NULL DEFAULT NULL,
  `Img` int(11) NULL DEFAULT NULL,
  `HeadFrameId` int(11) NULL DEFAULT NULL,
  `Sex` int(11) NULL DEFAULT NULL,
  `EarnSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `VipLevel` int(11) NULL DEFAULT NULL,
  `Level` int(11) NULL DEFAULT NULL,
  `AddressId` int(11) NULL DEFAULT NULL,
  `LastLoginTime` datetime NULL DEFAULT NULL,
  `Position` int(11) NOT NULL,
  `TodayCtrb` int(11) NULL DEFAULT NULL,
  `SumCtrb` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `GuildMember_Index`(`GuildId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildmemberbuild
-- ----------------------------
DROP TABLE IF EXISTS `guildmemberbuild`;
CREATE TABLE `guildmemberbuild`  (
  `AvatarId` bigint(20) NOT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `BuildTimes` int(11) NULL DEFAULT NULL,
  `GotRewards` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildmembersideline
-- ----------------------------
DROP TABLE IF EXISTS `guildmembersideline`;
CREATE TABLE `guildmembersideline`  (
  `AvatarId` bigint(20) NOT NULL,
  `Num` int(11) NOT NULL,
  `LastExcuteTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildmemberskill
-- ----------------------------
DROP TABLE IF EXISTS `guildmemberskill`;
CREATE TABLE `guildmemberskill`  (
  `AvatarId` bigint(20) NOT NULL,
  `Skill2Lv` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildmembertrade
-- ----------------------------
DROP TABLE IF EXISTS `guildmembertrade`;
CREATE TABLE `guildmembertrade`  (
  `AvatarId` bigint(20) NOT NULL,
  `LastEncounterTime` datetime NULL DEFAULT NULL,
  `HeroSendTimes` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildrecharge
-- ----------------------------
DROP TABLE IF EXISTS `guildrecharge`;
CREATE TABLE `guildrecharge`  (
  `GuildId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `ActivityId` int(11) NOT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `RechargeDic` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `RechargeMemberCount` int(11) NULL DEFAULT NULL,
  `MaxMemberCount` int(11) NULL DEFAULT NULL,
  `RewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  PRIMARY KEY (`ActivityId`, `GuildId`, `ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildsideline
-- ----------------------------
DROP TABLE IF EXISTS `guildsideline`;
CREATE TABLE `guildsideline`  (
  `GuildId` bigint(20) NOT NULL,
  `SideLineId` int(11) NULL DEFAULT NULL,
  `SideLineNum` int(11) NULL DEFAULT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `TodayAvatartNum` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `HistoryAvatartNum` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  PRIMARY KEY (`GuildId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildtrade
-- ----------------------------
DROP TABLE IF EXISTS `guildtrade`;
CREATE TABLE `guildtrade`  (
  `GuildId` bigint(20) NOT NULL,
  `OpenIndex` int(11) NOT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `TradeIdOpenTimes` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`GuildId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildtradeopen
-- ----------------------------
DROP TABLE IF EXISTS `guildtradeopen`;
CREATE TABLE `guildtradeopen`  (
  `GuildId` bigint(20) NOT NULL,
  `TradeId` int(11) NOT NULL,
  `OpenIndex` int(11) NOT NULL,
  `OpenTime` datetime NULL DEFAULT NULL,
  `StartTime` datetime NULL DEFAULT NULL,
  `HeroList` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `TotalEarnSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `Logs` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `EncounterDic` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `AvatarEncounterRewardDic` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `IsFinished` tinyint(1) NOT NULL DEFAULT 0,
  UNIQUE INDEX `GuildTradeOpen_Index`(`GuildId`, `OpenIndex`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for house_avatarhouse
-- ----------------------------
DROP TABLE IF EXISTS `house_avatarhouse`;
CREATE TABLE `house_avatarhouse`  (
  `Id` bigint(20) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `HouseId` int(11) NULL DEFAULT NULL,
  `HouseType` int(11) NULL DEFAULT NULL,
  `ShopAddtion` int(11) NULL DEFAULT NULL,
  `MaxHouseId` int(11) NULL DEFAULT NULL,
  `LastMailDay` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for house_avatarhouselog
-- ----------------------------
DROP TABLE IF EXISTS `house_avatarhouselog`;
CREATE TABLE `house_avatarhouselog`  (
  `AvatarId` bigint(20) NOT NULL,
  `Logs` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for house_serverhouses
-- ----------------------------
DROP TABLE IF EXISTS `house_serverhouses`;
CREATE TABLE `house_serverhouses`  (
  `Id` int(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `HouseType` int(11) NULL DEFAULT NULL,
  `Power` double NULL DEFAULT NULL,
  `HerosJson` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`Id`, `ServerId`) USING BTREE,
  INDEX `ix_houseserverhouses_serverid`(`ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for jsontemporary
-- ----------------------------
DROP TABLE IF EXISTS `jsontemporary`;
CREATE TABLE `jsontemporary`  (
  `msg` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for kidrank
-- ----------------------------
DROP TABLE IF EXISTS `kidrank`;
CREATE TABLE `kidrank`  (
  `Id` int(11) NULL DEFAULT NULL,
  `PlayerId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `UpdateTime` datetime(2) NULL DEFAULT NULL,
  `MakeMoney` double NULL DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Sex` int(11) NULL DEFAULT NULL,
  `Job` int(11) NULL DEFAULT NULL,
  `MomBeautyId` int(11) NULL DEFAULT NULL,
  `Quality` int(11) NULL DEFAULT NULL,
  `WorkId` int(11) NULL DEFAULT NULL,
  `Twins` tinyint(4) NULL DEFAULT NULL,
  `MomBeautyIntimacy` int(11) NULL DEFAULT NULL,
  `PlayerName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Rank` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`PlayerId`) USING BTREE,
  UNIQUE INDEX `ix_kidrank_key`(`PlayerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for lanternfestival
-- ----------------------------
DROP TABLE IF EXISTS `lanternfestival`;
CREATE TABLE `lanternfestival`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `CompensatedItem` tinyint(1) NOT NULL DEFAULT 0,
  `CompensateItemTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `LanternFestival_Index`(`ActivityId`, `ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for lanternfestivalavatar
-- ----------------------------
DROP TABLE IF EXISTS `lanternfestivalavatar`;
CREATE TABLE `lanternfestivalavatar`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `Score` int(11) NULL DEFAULT NULL,
  `LastScoreTime` datetime NULL DEFAULT NULL,
  `Round` int(11) NULL DEFAULT NULL,
  `Balls` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `OpIndex` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `LanternFestivalAvatar_Index`(`ActivityId`, `AvatarId`, `ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 226 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for lanternfestivalavatarcolddata
-- ----------------------------
DROP TABLE IF EXISTS `lanternfestivalavatarcolddata`;
CREATE TABLE `lanternfestivalavatarcolddata`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `RewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `MailRewards` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailTime` datetime NULL DEFAULT NULL,
  `MailCompensateItems` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailCompensateItemTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `LanternFestivalAvatarColdData_Index`(`ActivityId`, `AvatarId`, `ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 221 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for lanternfestivalavatarlog
-- ----------------------------
DROP TABLE IF EXISTS `lanternfestivalavatarlog`;
CREATE TABLE `lanternfestivalavatarlog`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `OpIndex` int(11) NULL DEFAULT NULL,
  `Round` int(11) NOT NULL,
  `Balls` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `SubmitBalls` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `AddScore` int(11) NULL DEFAULT NULL,
  `CurScore` int(11) NULL DEFAULT NULL,
  `OpTime` datetime NULL DEFAULT NULL,
  `Reason` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `LanternFestivalAvatarLog_Index`(`ActivityId`, `AvatarId`, `OpIndex`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for luckyextractavatar
-- ----------------------------
DROP TABLE IF EXISTS `luckyextractavatar`;
CREATE TABLE `luckyextractavatar`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NOT NULL,
  `ExtractIndex` int(11) NOT NULL,
  `LuckyValue` int(11) NULL DEFAULT NULL,
  `LuckyValueResetTime` datetime NULL DEFAULT NULL,
  `First10TimesReward` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `LuckyExtractAvatar_Index`(`AvatarId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6182 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for luckyextractlog
-- ----------------------------
DROP TABLE IF EXISTS `luckyextractlog`;
CREATE TABLE `luckyextractlog`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ExtractIndex` int(11) NOT NULL,
  `ExtractReward` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ExtractTime` datetime NULL DEFAULT NULL,
  `IsLuckyValueFull` tinyint(1) NOT NULL DEFAULT 0,
  `NeedShow` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `LuckyExtractAvatarLog_Index`(`AvatarId`, `ServerId`, `ExtractIndex`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1928 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for managementlog
-- ----------------------------
DROP TABLE IF EXISTS `managementlog`;
CREATE TABLE `managementlog`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Operator` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `Function` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `Time` datetime NULL DEFAULT NULL,
  `Detail` varchar(5000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 32 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for marriageshare
-- ----------------------------
DROP TABLE IF EXISTS `marriageshare`;
CREATE TABLE `marriageshare`  (
  `Id` int(11) NULL DEFAULT NULL,
  `ServerId` int(11) NOT NULL COMMENT '区服id',
  `ProposalId` int(11) NOT NULL COMMENT '联姻Id',
  `AvatarId` bigint(20) NULL DEFAULT NULL COMMENT '请求联姻玩家id',
  `KidId` int(11) NULL DEFAULT NULL COMMENT '请求联姻子嗣Id',
  `KidName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '请求联姻子嗣昵称',
  `Sex` tinyint(4) NULL DEFAULT NULL COMMENT '提亲玩家子嗣性别',
  `EarnSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '提亲子嗣赚速',
  `ProposalStatus` int(11) NULL DEFAULT NULL COMMENT '提亲状态',
  `AssignAvatarId` bigint(20) NULL DEFAULT NULL COMMENT '对方玩家Id',
  `AssignKidId` int(11) NULL DEFAULT NULL COMMENT '对方子嗣Id',
  `AssignEarnSpeed` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '对方子嗣赚速',
  `CreateTime` datetime NULL DEFAULT NULL COMMENT '提亲时间',
  `UpdateTime` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `IsLose` tinyint(4) NULL DEFAULT NULL COMMENT '是否失效',
  PRIMARY KEY (`ServerId`, `ProposalId`) USING BTREE,
  INDEX `MarriageKey`(`ServerId`, `ProposalId`) USING BTREE,
  INDEX `IsLose`(`IsLose`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for notice_gamenotice
-- ----------------------------
DROP TABLE IF EXISTS `notice_gamenotice`;
CREATE TABLE `notice_gamenotice`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Type` int(11) NULL DEFAULT NULL,
  `Title` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Content` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `STime` bigint(20) NULL DEFAULT NULL,
  `ETime` bigint(20) NULL DEFAULT NULL,
  `PlatformId` varchar(5000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ChannelId` varchar(5000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ServerId` varchar(5000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 30 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for notice_marqueenews
-- ----------------------------
DROP TABLE IF EXISTS `notice_marqueenews`;
CREATE TABLE `notice_marqueenews`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Content` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `STime` bigint(20) NULL DEFAULT NULL,
  `ETime` bigint(20) NULL DEFAULT NULL,
  `PlatformId` varchar(5000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ChannelId` varchar(5000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ServerId` varchar(5000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `FontColor` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ShowTimes` int(11) NULL DEFAULT NULL,
  `Interval` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for orleans.runtime.versions.versionstoregrain
-- ----------------------------
DROP TABLE IF EXISTS `orleans.runtime.versions.versionstoregrain`;
CREATE TABLE `orleans.runtime.versions.versionstoregrain`  (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `GrainIdHash` int(11) NOT NULL,
  `GrainIdN0` bigint(20) NOT NULL,
  `GrainIdN1` bigint(20) NOT NULL,
  `GrainTypeHash` int(11) NOT NULL,
  `GrainTypeString` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `GrainIdExtensionString` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ServiceId` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `PayloadBinary` blob NULL,
  `PayloadXml` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `PayloadJson` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ModifiedOn` datetime NOT NULL,
  `Version` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IX_Orleans.Runtime.Versions.VersionStoreGrain`(`GrainIdHash`, `GrainTypeHash`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci KEY_BLOCK_SIZE = 16 ROW_FORMAT = COMPRESSED;

-- ----------------------------
-- Table structure for orleansquery
-- ----------------------------
DROP TABLE IF EXISTS `orleansquery`;
CREATE TABLE `orleansquery`  (
  `QueryKey` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `QueryText` varchar(8000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`QueryKey`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of orleansquery
-- ----------------------------
INSERT INTO `orleansquery` VALUES ('ClearStorageKey', 'call ClearStorage(@GrainIdHash, @GrainIdN0, @GrainIdN1, @GrainTypeHash, @GrainTypeString, @GrainIdExtensionString, @ServiceId, @GrainStateVersion);');
INSERT INTO `orleansquery` VALUES ('DeleteReminderRowKey', '\r\n    DELETE FROM OrleansRemindersTable\r\n    WHERE\r\n        ServiceId = @ServiceId AND @ServiceId IS NOT NULL\r\n        AND GrainId = @GrainId AND @GrainId IS NOT NULL\r\n        AND ReminderName = @ReminderName AND @ReminderName IS NOT NULL\r\n        AND Version = @Version AND @Version IS NOT NULL;\r\n    SELECT ROW_COUNT();\r\n');
INSERT INTO `orleansquery` VALUES ('DeleteReminderRowsKey', '\r\n    DELETE FROM OrleansRemindersTable\r\n    WHERE\r\n        ServiceId = @ServiceId AND @ServiceId IS NOT NULL;\r\n');
INSERT INTO `orleansquery` VALUES ('ReadFromStorageKey', 'call ReadStorage(@GrainIdHash, @GrainIdN0, @GrainIdN1, @GrainTypeHash, @GrainTypeString, @GrainIdExtensionString, @ServiceId);');
INSERT INTO `orleansquery` VALUES ('ReadRangeRows1Key', '\r\n    SELECT\r\n        GrainId,\r\n        ReminderName,\r\n        StartTime,\r\n        Period,\r\n        Version\r\n    FROM OrleansRemindersTable\r\n    WHERE\r\n        ServiceId = @ServiceId AND @ServiceId IS NOT NULL\r\n        AND GrainHash > @BeginHash AND @BeginHash IS NOT NULL\r\n        AND GrainHash <= @EndHash AND @EndHash IS NOT NULL;\r\n');
INSERT INTO `orleansquery` VALUES ('ReadRangeRows2Key', '\r\n    SELECT\r\n        GrainId,\r\n        ReminderName,\r\n        StartTime,\r\n        Period,\r\n        Version\r\n    FROM OrleansRemindersTable\r\n    WHERE\r\n        ServiceId = @ServiceId AND @ServiceId IS NOT NULL\r\n        AND ((GrainHash > @BeginHash AND @BeginHash IS NOT NULL)\r\n        OR (GrainHash <= @EndHash AND @EndHash IS NOT NULL));\r\n');
INSERT INTO `orleansquery` VALUES ('ReadReminderRowKey', '\r\n    SELECT\r\n        GrainId,\r\n        ReminderName,\r\n        StartTime,\r\n        Period,\r\n        Version\r\n    FROM OrleansRemindersTable\r\n    WHERE\r\n        ServiceId = @ServiceId AND @ServiceId IS NOT NULL\r\n        AND GrainId = @GrainId AND @GrainId IS NOT NULL\r\n        AND ReminderName = @ReminderName AND @ReminderName IS NOT NULL;\r\n');
INSERT INTO `orleansquery` VALUES ('ReadReminderRowsKey', '\r\n    SELECT\r\n        GrainId,\r\n        ReminderName,\r\n        StartTime,\r\n        Period,\r\n        Version\r\n    FROM OrleansRemindersTable\r\n    WHERE\r\n        ServiceId = @ServiceId AND @ServiceId IS NOT NULL\r\n        AND GrainId = @GrainId AND @GrainId IS NOT NULL;\r\n');
INSERT INTO `orleansquery` VALUES ('UpsertReminderRowKey', '\r\n    INSERT INTO OrleansRemindersTable\r\n    (\r\n        ServiceId,\r\n        GrainId,\r\n        ReminderName,\r\n        StartTime,\r\n        Period,\r\n        GrainHash,\r\n        Version\r\n    )\r\n    VALUES\r\n    (\r\n        @ServiceId,\r\n        @GrainId,\r\n        @ReminderName,\r\n        @StartTime,\r\n        @Period,\r\n        @GrainHash,\r\n        last_insert_id(0)\r\n    )\r\n    ON DUPLICATE KEY\r\n    UPDATE\r\n        StartTime = @StartTime,\r\n        Period = @Period,\r\n        GrainHash = @GrainHash,\r\n        Version = last_insert_id(Version+1);\r\n\r\n\r\n    SELECT last_insert_id() AS Version;\r\n');
INSERT INTO `orleansquery` VALUES ('WriteToStorageKey', 'call WriteToStorage(@GrainIdHash, @GrainIdN0, @GrainIdN1, @GrainTypeHash, @GrainTypeString, @GrainIdExtensionString, @ServiceId, @GrainStateVersion, @PayloadBinary, @PayloadJson, @PayloadXml);');

-- ----------------------------
-- Table structure for orleansreminderstable
-- ----------------------------
DROP TABLE IF EXISTS `orleansreminderstable`;
CREATE TABLE `orleansreminderstable`  (
  `ServiceId` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `GrainId` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ReminderName` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `StartTime` datetime NOT NULL,
  `Period` bigint(20) NOT NULL,
  `GrainHash` int(11) NOT NULL,
  `Version` int(11) NOT NULL,
  PRIMARY KEY (`ServiceId`, `GrainId`, `ReminderName`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for orleansstorage
-- ----------------------------
DROP TABLE IF EXISTS `orleansstorage`;
CREATE TABLE `orleansstorage`  (
  `GrainIdHash` int(11) NOT NULL,
  `GrainIdN0` bigint(20) NOT NULL,
  `GrainIdN1` bigint(20) NOT NULL,
  `GrainTypeHash` int(11) NOT NULL,
  `GrainTypeString` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `GrainIdExtensionString` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ServiceId` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `PayloadBinary` blob NULL,
  `PayloadXml` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `PayloadJson` json NULL,
  `ModifiedOn` datetime NOT NULL,
  `Version` int(11) NULL DEFAULT NULL,
  INDEX `IX_OrleansStorage`(`GrainIdHash`, `GrainTypeHash`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci KEY_BLOCK_SIZE = 16 ROW_FORMAT = COMPRESSED;

-- ----------------------------
-- Table structure for pass
-- ----------------------------
DROP TABLE IF EXISTS `pass`;
CREATE TABLE `pass`  (
  `AvatarId` bigint(20) NOT NULL,
  `ActivityId` int(11) NOT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `Level` int(11) NULL DEFAULT NULL,
  `Exp` int(11) NULL DEFAULT NULL,
  `IsToll` tinyint(1) NULL DEFAULT NULL,
  `ReceiveFree` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ReceiveToll` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `TaskNextResetTime` datetime NULL DEFAULT NULL,
  `WeekCount` int(11) NULL DEFAULT NULL,
  `MailRewards` varchar(5000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MailTime` datetime NULL DEFAULT NULL,
  UNIQUE INDEX `Pass_Index`(`AvatarId`, `ActivityId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for passreceivelog
-- ----------------------------
DROP TABLE IF EXISTS `passreceivelog`;
CREATE TABLE `passreceivelog`  (
  `AvatarId` bigint(20) NOT NULL,
  `ActivityId` int(11) NOT NULL,
  `Level` int(11) NOT NULL,
  `RewardFree` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `RewardToll` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  INDEX `PassReceiveLog_Index`(`AvatarId`, `ActivityId`, `Level`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for passtask
-- ----------------------------
DROP TABLE IF EXISTS `passtask`;
CREATE TABLE `passtask`  (
  `AvatarId` bigint(20) NOT NULL,
  `ActivityId` int(11) NOT NULL,
  `WeekCount` int(11) NULL DEFAULT NULL,
  `TaskId` int(11) NOT NULL,
  `Progress` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  UNIQUE INDEX `PassTask_Index`(`AvatarId`, `ActivityId`, `WeekCount`, `TaskId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for petlog
-- ----------------------------
DROP TABLE IF EXISTS `petlog`;
CREATE TABLE `petlog`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UpdateTime` datetime NULL DEFAULT NULL,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `PetId` int(11) NULL DEFAULT NULL,
  `ModelId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `ix_petlog_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 105688 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for pray
-- ----------------------------
DROP TABLE IF EXISTS `pray`;
CREATE TABLE `pray`  (
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `PrayCount` int(11) NOT NULL,
  `LastPrayTime` datetime NULL DEFAULT NULL,
  `MyPools` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `RewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  UNIQUE INDEX `RoyalHuntAvatar_Index`(`ActivityId`, `AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for praylog
-- ----------------------------
DROP TABLE IF EXISTS `praylog`;
CREATE TABLE `praylog`  (
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `PrayCount` bigint(20) NOT NULL,
  `MyPools` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `PrayTime` datetime NULL DEFAULT NULL,
  UNIQUE INDEX `RoyalHuntAvatarLog_Index`(`ActivityId`, `AvatarId`, `PrayCount`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for privilegecardrewardlog
-- ----------------------------
DROP TABLE IF EXISTS `privilegecardrewardlog`;
CREATE TABLE `privilegecardrewardlog`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NOT NULL,
  `DateKey` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CardId` int(11) NOT NULL,
  `ReceiveTime` datetime NULL DEFAULT NULL,
  `Reward` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `PrivilegeCardRewardLog_Index`(`AvatarId`, `DateKey`, `CardId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 118 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for project
-- ----------------------------
DROP TABLE IF EXISTS `project`;
CREATE TABLE `project`  (
  `GroupId` int(11) NOT NULL,
  `ProjectId` bigint(20) NOT NULL,
  `EventIndex` bigint(20) NOT NULL,
  `WeekIndex` int(11) NOT NULL,
  `ProjectType` int(11) NOT NULL,
  `OwnerId` bigint(20) NOT NULL,
  `ScorePerMin` int(11) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `StartTime` datetime NULL DEFAULT NULL,
  `EndTime` datetime NULL DEFAULT NULL,
  `IsEnd` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`GroupId`, `ProjectId`) USING BTREE,
  INDEX `Project_Index`(`WeekIndex`, `IsEnd`, `ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for projectavatar
-- ----------------------------
DROP TABLE IF EXISTS `projectavatar`;
CREATE TABLE `projectavatar`  (
  `AvatarId` bigint(20) NOT NULL,
  `TodayTimes` int(11) NOT NULL,
  `ReadBattleLogTime` datetime NULL DEFAULT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  UNIQUE INDEX `ProjectAvatar_Index`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for projectavatarscore
-- ----------------------------
DROP TABLE IF EXISTS `projectavatarscore`;
CREATE TABLE `projectavatarscore`  (
  `GroupId` int(11) NOT NULL,
  `WeekIndex` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `ProjectType` int(11) NOT NULL,
  `Score` bigint(20) NOT NULL,
  `LastScoreTime` datetime NULL DEFAULT NULL,
  `CreateTime` datetime NULL DEFAULT NULL,
  UNIQUE INDEX `ProjectAvatarScore_Index`(`GroupId`, `WeekIndex`, `AvatarId`, `ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for projectavatarscorelog
-- ----------------------------
DROP TABLE IF EXISTS `projectavatarscorelog`;
CREATE TABLE `projectavatarscorelog`  (
  `AvatarId` bigint(20) NOT NULL,
  `ProjectId` bigint(20) NOT NULL,
  `GroupId` int(11) NOT NULL,
  `WeekIndex` bigint(20) NOT NULL,
  `IsRead` tinyint(1) NOT NULL DEFAULT 0,
  `EventIndex` bigint(20) NOT NULL,
  `ProjectType` int(11) NOT NULL,
  `ScoreEventType` int(11) NOT NULL,
  `EventTime` datetime NULL DEFAULT NULL,
  `StartTime` datetime NULL DEFAULT NULL,
  `EndTime` datetime NULL DEFAULT NULL,
  `AddScore` int(11) NOT NULL,
  `EnemyId` bigint(20) NOT NULL,
  `EnemyName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `EnemyServerId` int(11) NOT NULL,
  UNIQUE INDEX `ProjectAvatarScoreLog_Index`(`AvatarId`, `GroupId`, `ProjectId`, `WeekIndex`, `EventIndex`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for projectavatarweek
-- ----------------------------
DROP TABLE IF EXISTS `projectavatarweek`;
CREATE TABLE `projectavatarweek`  (
  `GroupId` int(11) NOT NULL,
  `WeekIndex` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ZanRanks` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `CreateTime` datetime NULL DEFAULT NULL,
  UNIQUE INDEX `ProjectAvatarWeek_Index`(`WeekIndex`, `GroupId`, `AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for projectbattlelog
-- ----------------------------
DROP TABLE IF EXISTS `projectbattlelog`;
CREATE TABLE `projectbattlelog`  (
  `GroupId` int(11) NOT NULL,
  `ProjectId` bigint(20) NOT NULL,
  `WeekIndex` bigint(20) NOT NULL,
  `EventIndex` bigint(20) NOT NULL,
  `ProjectType` int(11) NOT NULL,
  `EventType` int(11) NOT NULL,
  `EventTime` datetime NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ServerId` int(11) NOT NULL,
  `TitleId` int(11) NOT NULL,
  `TitleIds` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `Lv` int(11) NOT NULL,
  `Prestige` bigint(20) NOT NULL,
  `Seat` int(11) NOT NULL,
  `EnemyId` bigint(20) NOT NULL,
  `EnemyName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `EnemyServerId` int(11) NOT NULL,
  `EnemyTitleId` int(11) NOT NULL,
  `EnemyTitleIds` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EnemyLv` int(11) NOT NULL,
  `EnemyPrestige` bigint(20) NOT NULL,
  `EnemyAddScore` bigint(20) NOT NULL,
  UNIQUE INDEX `ProjectBattleLog_Index`(`GroupId`, `ProjectId`, `WeekIndex`, `EventIndex`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for projectgroup
-- ----------------------------
DROP TABLE IF EXISTS `projectgroup`;
CREATE TABLE `projectgroup`  (
  `GroupId` int(11) NOT NULL,
  `WeekIndex` int(11) NOT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `NextResetDate` datetime NULL DEFAULT NULL,
  UNIQUE INDEX `ProjectGroup_Index`(`GroupId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for projectlog
-- ----------------------------
DROP TABLE IF EXISTS `projectlog`;
CREATE TABLE `projectlog`  (
  `GroupId` int(11) NOT NULL,
  `ProjectId` bigint(20) NOT NULL,
  `EventIndex` bigint(20) NOT NULL,
  `EventType` int(11) NOT NULL,
  `EventTime` datetime NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ServerId` int(11) NOT NULL,
  `EnemyId` bigint(20) NOT NULL,
  `EnemyName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `EnemyServerId` int(11) NOT NULL,
  UNIQUE INDEX `ProjectLog_Index`(`GroupId`, `ProjectId`, `EventIndex`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for projectmember
-- ----------------------------
DROP TABLE IF EXISTS `projectmember`;
CREATE TABLE `projectmember`  (
  `GroupId` int(11) NOT NULL,
  `ProjectId` bigint(20) NOT NULL,
  `Seat` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ServerId` int(11) NOT NULL,
  `JoinTime` datetime NULL DEFAULT NULL,
  `TitleId` int(11) NULL DEFAULT NULL,
  `TitleIds` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `Lv` int(11) NOT NULL,
  `Prestige` bigint(20) NOT NULL,
  UNIQUE INDEX `ProjectMember_Index`(`GroupId`, `ProjectId`, `Seat`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for prop_item
-- ----------------------------
DROP TABLE IF EXISTS `prop_item`;
CREATE TABLE `prop_item`  (
  `Id` int(20) NOT NULL COMMENT '道具Id',
  `AvatarId` bigint(20) NOT NULL COMMENT '玩家Id',
  `Count` double NULL DEFAULT NULL COMMENT '道具数量',
  `UpdateTime` bigint(20) NULL DEFAULT NULL COMMENT '最后更新时间戳',
  PRIMARY KEY (`AvatarId`, `Id`) USING BTREE,
  INDEX `ix_propitem_avatarid`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for questionnaireanswer
-- ----------------------------
DROP TABLE IF EXISTS `questionnaireanswer`;
CREATE TABLE `questionnaireanswer`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `Answer` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `Lv` int(11) NULL DEFAULT NULL,
  `Vip` int(11) NULL DEFAULT NULL,
  `Question` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `QuestionnaireId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for questionnairedonerecord
-- ----------------------------
DROP TABLE IF EXISTS `questionnairedonerecord`;
CREATE TABLE `questionnairedonerecord`  (
  `AvatarId` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ServerId` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `QuestionnaireId` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Type` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `DoneTime` datetime NULL DEFAULT NULL,
  `Rewarded` tinyint(1) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for questionnairerecord
-- ----------------------------
DROP TABLE IF EXISTS `questionnairerecord`;
CREATE TABLE `questionnairerecord`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `QuestionnaireId` int(11) NULL DEFAULT NULL,
  `IsComplete` tinyint(1) NULL DEFAULT NULL,
  `IsReward` tinyint(1) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for receivewaterlog
-- ----------------------------
DROP TABLE IF EXISTS `receivewaterlog`;
CREATE TABLE `receivewaterlog`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `FromAvatarId` bigint(20) NOT NULL,
  `CurScore` bigint(20) NOT NULL,
  `AddScore` bigint(20) NOT NULL,
  `ReceiveTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `ReceiveWaterLog_Index`(`ActivityId`, `AvatarId`, `FromAvatarId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for rechargeorder
-- ----------------------------
DROP TABLE IF EXISTS `rechargeorder`;
CREATE TABLE `rechargeorder`  (
  `Id` int(11) NULL DEFAULT NULL,
  `ServerId` int(11) NOT NULL,
  `Sign` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Rsdk_order_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'RSDK 订单 ID，如：\"6sbj\"。该订单号需要区分大小写，对接方需要对此进行处理，避免订单号重复',
  `Platform_order_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '渠道订单号，如：\"1602161513136180362\"。',
  `Product_count` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品份数',
  `Product_extra_count` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Amount` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Pay_time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Pid_prefix` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `User_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Game_user_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Server_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Product_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Product_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Product_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Private_data` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Trade_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Money_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Os` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Point` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Free_point` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `If_get_item_by_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Ext_vchar1` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Source` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Event_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Token` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  `Msg` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `CreateTime` datetime NULL DEFAULT NULL,
  `Status` int(11) NULL DEFAULT NULL COMMENT '订单状态 -1 验证失败订单 0 未验证订单 1 已验证订单 2 已发货 ',
  PRIMARY KEY (`ServerId`, `Sign`) USING BTREE,
  INDEX `ix_rechargeorder_key`(`ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for redeemcoderecord
-- ----------------------------
DROP TABLE IF EXISTS `redeemcoderecord`;
CREATE TABLE `redeemcoderecord`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AvatarId` int(20) NULL DEFAULT NULL,
  `GiftId` int(11) NULL DEFAULT NULL,
  `RedeemCode` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Time` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for resourceaccount
-- ----------------------------
DROP TABLE IF EXISTS `resourceaccount`;
CREATE TABLE `resourceaccount`  (
  `AvatarId` int(20) NOT NULL,
  `Name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Owner` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `GoldCount` int(20) NULL DEFAULT NULL,
  `ServerId` int(10) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for resourceaccountgift
-- ----------------------------
DROP TABLE IF EXISTS `resourceaccountgift`;
CREATE TABLE `resourceaccountgift`  (
  `AvatarId` int(20) NOT NULL,
  `Cycle` int(11) NULL DEFAULT NULL,
  `Hour` int(11) NULL DEFAULT NULL,
  `GradeId` int(11) NULL DEFAULT NULL,
  `LastTime` datetime NULL DEFAULT NULL,
  `NextTime` datetime NULL DEFAULT NULL,
  `UserId` int(20) NULL DEFAULT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `GiftName` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Gold` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for resourcegiftrecord
-- ----------------------------
DROP TABLE IF EXISTS `resourcegiftrecord`;
CREATE TABLE `resourcegiftrecord`  (
  `Id` int(20) NOT NULL AUTO_INCREMENT,
  `AvatarId` int(11) NULL DEFAULT NULL,
  `Name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Owner` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `GiftName` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Time` datetime NULL DEFAULT NULL,
  `Report` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for routerank
-- ----------------------------
DROP TABLE IF EXISTS `routerank`;
CREATE TABLE `routerank`  (
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `Score` double NULL DEFAULT NULL,
  `RankTime` datetime(2) NULL DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Level` int(11) NULL DEFAULT NULL,
  `HeadId` int(11) NULL DEFAULT NULL,
  `HeadFrameId` int(11) NULL DEFAULT NULL,
  `VipLevel` int(11) NULL DEFAULT NULL,
  `AddressId` int(11) NULL DEFAULT NULL,
  `TitleId` int(11) NULL DEFAULT NULL,
  `Image` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  UNIQUE INDEX `ix_routerank_key`(`AvatarId`) USING BTREE,
  INDEX `ix_routerank_serverid`(`ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for royalhunt
-- ----------------------------
DROP TABLE IF EXISTS `royalhunt`;
CREATE TABLE `royalhunt`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `CompensatedItem` tinyint(1) NOT NULL DEFAULT 0,
  `CompensateItemTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `RoyalHunt_Index`(`ActivityId`, `ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for royalhuntavatar
-- ----------------------------
DROP TABLE IF EXISTS `royalhuntavatar`;
CREATE TABLE `royalhuntavatar`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `OpIndex` bigint(20) NOT NULL,
  `Score` int(11) NULL DEFAULT NULL,
  `LastScoreTime` datetime NULL DEFAULT NULL,
  `UsedPower` int(11) NULL DEFAULT NULL,
  `LastPowerChangeTime` datetime NULL DEFAULT NULL,
  `CurArr` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `NextPet` int(11) NULL DEFAULT NULL,
  `NextHighPet` int(11) NULL DEFAULT NULL,
  `HoldPet` int(11) NULL DEFAULT NULL,
  `Tools` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `RoyalHuntAvatar_Index`(`ActivityId`, `AvatarId`, `ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4887 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for royalhuntavatarcolddata
-- ----------------------------
DROP TABLE IF EXISTS `royalhuntavatarcolddata`;
CREATE TABLE `royalhuntavatarcolddata`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `StartArr` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `UnlockPets` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `RewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `PetRewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `MailRewards` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailTime` datetime NULL DEFAULT NULL,
  `MailCompensateItems` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailCompensateItemTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `RoyalHuntAvatarColdData_Index`(`ActivityId`, `AvatarId`, `ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 443 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for royalhuntavatarlog
-- ----------------------------
DROP TABLE IF EXISTS `royalhuntavatarlog`;
CREATE TABLE `royalhuntavatarlog`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `OpIndex` bigint(20) NOT NULL,
  `OldArr` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CurArr` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `AddScore` int(11) NULL DEFAULT NULL,
  `CancelSubScore` int(11) NULL DEFAULT NULL,
  `CurScore` int(11) NULL DEFAULT NULL,
  `NextPet` int(11) NULL DEFAULT NULL,
  `NextHighPet` int(11) NULL DEFAULT NULL,
  `HoldPet` int(11) NULL DEFAULT NULL,
  `ToolId` int(11) NULL DEFAULT NULL,
  `PetId` int(11) NULL DEFAULT NULL,
  `X` int(11) NULL DEFAULT NULL,
  `Y` int(11) NULL DEFAULT NULL,
  `Reward` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CancelSubReward` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `OpTime` datetime NULL DEFAULT NULL,
  `Reason` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `RoyalHuntAvatarLog_Index`(`ActivityId`, `AvatarId`, `OpIndex`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3825 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for sailina.tang.player.chamber
-- ----------------------------
DROP TABLE IF EXISTS `sailina.tang.player.chamber`;
CREATE TABLE `sailina.tang.player.chamber`  (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `GrainIdHash` int(11) NOT NULL,
  `GrainIdN0` bigint(20) NOT NULL,
  `GrainIdN1` bigint(20) NOT NULL,
  `GrainTypeHash` int(11) NOT NULL,
  `GrainTypeString` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `GrainIdExtensionString` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ServiceId` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `PayloadBinary` blob NULL,
  `PayloadXml` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `PayloadJson` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ModifiedOn` datetime NOT NULL,
  `Version` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IX_Sailina.Tang.Player.Chamber`(`GrainIdHash`, `GrainTypeHash`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci KEY_BLOCK_SIZE = 16 ROW_FORMAT = COMPRESSED;

-- ----------------------------
-- Table structure for sailina.tang.player.chamberset
-- ----------------------------
DROP TABLE IF EXISTS `sailina.tang.player.chamberset`;
CREATE TABLE `sailina.tang.player.chamberset`  (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `GrainIdHash` int(11) NOT NULL,
  `GrainIdN0` bigint(20) NOT NULL,
  `GrainIdN1` bigint(20) NOT NULL,
  `GrainTypeHash` int(11) NOT NULL,
  `GrainTypeString` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `GrainIdExtensionString` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ServiceId` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `PayloadBinary` blob NULL,
  `PayloadXml` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `PayloadJson` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ModifiedOn` datetime NOT NULL,
  `Version` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IX_Sailina.Tang.Player.ChamberSet`(`GrainIdHash`, `GrainTypeHash`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci KEY_BLOCK_SIZE = 16 ROW_FORMAT = COMPRESSED;

-- ----------------------------
-- Table structure for server
-- ----------------------------
DROP TABLE IF EXISTS `server`;
CREATE TABLE `server`  (
  `Id` bigint(11) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `GameSqlConn` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ConfigSqlConn` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Status` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`ServerId`, `Id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for serveremailtemplate
-- ----------------------------
DROP TABLE IF EXISTS `serveremailtemplate`;
CREATE TABLE `serveremailtemplate`  (
  `ServerId` int(11) NOT NULL,
  `TemplateType` int(11) NOT NULL,
  `EmailType` int(11) NOT NULL,
  `Title` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Content` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Rewards` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ExpireDays` int(11) NOT NULL,
  `ExpireTime` datetime NULL DEFAULT NULL,
  UNIQUE INDEX `ServerEmailTemplate_Index`(`ServerId`, `TemplateType`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for serverkidproposal
-- ----------------------------
DROP TABLE IF EXISTS `serverkidproposal`;
CREATE TABLE `serverkidproposal`  (
  `Id` int(11) NULL DEFAULT NULL,
  `ServerId` int(11) NOT NULL,
  `MaxProposalId` int(11) NULL DEFAULT NULL,
  `MarriageShareDic` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `LaseClearTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`ServerId`) USING BTREE,
  INDEX `ix_serverkidproposal_key`(`ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for serverrechargeorder
-- ----------------------------
DROP TABLE IF EXISTS `serverrechargeorder`;
CREATE TABLE `serverrechargeorder`  (
  `Id` int(11) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `ProductId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Num` int(11) NULL DEFAULT NULL,
  `Status` int(11) NULL DEFAULT NULL,
  `Msg` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `CreateTime` datetime NULL DEFAULT NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  `Info` json NULL,
  `OrderId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ServerId`, `Id`) USING BTREE,
  INDEX `ix_rechargeorder_key`(`ServerId`) USING BTREE,
  INDEX `ix_server_avatarId`(`ServerId`, `AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for serversendmoney
-- ----------------------------
DROP TABLE IF EXISTS `serversendmoney`;
CREATE TABLE `serversendmoney`  (
  `Id` int(11) NULL DEFAULT NULL,
  `ServerId` int(11) NOT NULL,
  `GradeId` int(11) NOT NULL,
  `Content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `CreateTime` datetime NULL DEFAULT NULL,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`GradeId`, `ServerId`) USING BTREE,
  INDEX `ix_serversendmoney_key`(`ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for signin
-- ----------------------------
DROP TABLE IF EXISTS `signin`;
CREATE TABLE `signin`  (
  `AvatarId` bigint(20) NOT NULL,
  `Round` int(11) NOT NULL,
  `SignInDays` int(11) NULL DEFAULT NULL,
  `SupplementarySignIn` int(11) NULL DEFAULT NULL,
  `LastSignInTime` datetime NULL DEFAULT NULL,
  `StartTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for simulationrechargerecord
-- ----------------------------
DROP TABLE IF EXISTS `simulationrechargerecord`;
CREATE TABLE `simulationrechargerecord`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Operator` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Time` datetime NULL DEFAULT NULL,
  `Product` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ProductId` int(11) NULL DEFAULT NULL,
  `AvatarId` int(11) NULL DEFAULT NULL,
  `Name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `Result` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Vip` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for springfestival
-- ----------------------------
DROP TABLE IF EXISTS `springfestival`;
CREATE TABLE `springfestival`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `CompensatedItem` tinyint(1) NOT NULL DEFAULT 0,
  `CompensateItemTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `SpringFestival_Index`(`ActivityId`, `ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for springfestivalavatar
-- ----------------------------
DROP TABLE IF EXISTS `springfestivalavatar`;
CREATE TABLE `springfestivalavatar`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `Score` int(11) NULL DEFAULT NULL,
  `LastScoreTime` datetime NULL DEFAULT NULL,
  `LastPowerChangeTime` datetime NULL DEFAULT NULL,
  `CurArr` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `OpIndex` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `SpringFestivalAvatar_Index`(`ActivityId`, `AvatarId`, `ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3319 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for springfestivalavatarcolddata
-- ----------------------------
DROP TABLE IF EXISTS `springfestivalavatarcolddata`;
CREATE TABLE `springfestivalavatarcolddata`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `StartArr` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `RewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `TaskRewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `MailRewards` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailTime` datetime NULL DEFAULT NULL,
  `MailCompensateItems` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailCompensateItemTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `SpringFestivalAvatarColdData_Index`(`ActivityId`, `AvatarId`, `ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 260 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for springfestivalavatarlog
-- ----------------------------
DROP TABLE IF EXISTS `springfestivalavatarlog`;
CREATE TABLE `springfestivalavatarlog`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `OpIndex` int(11) NULL DEFAULT NULL,
  `CurArr` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `AddScore` int(11) NULL DEFAULT NULL,
  `CurScore` int(11) NULL DEFAULT NULL,
  `OpTime` datetime NULL DEFAULT NULL,
  `Reason` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `SpringFestivalAvatarLog_Index`(`ActivityId`, `AvatarId`, `OpIndex`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 828 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for store_activityexchange
-- ----------------------------
DROP TABLE IF EXISTS `store_activityexchange`;
CREATE TABLE `store_activityexchange`  (
  `AvatarId` bigint(20) NOT NULL,
  `ActivityExchanges` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for store_avatarexchangehistory
-- ----------------------------
DROP TABLE IF EXISTS `store_avatarexchangehistory`;
CREATE TABLE `store_avatarexchangehistory`  (
  `Id` bigint(20) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `CommodityId` int(11) NOT NULL,
  `BuyTime` bigint(20) NOT NULL,
  `BuyNum` int(11) NULL DEFAULT NULL,
  `BatchKey` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `StoreId` int(11) NULL DEFAULT NULL,
  `PrimaryKeyId` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`PrimaryKeyId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 96 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for store_avatarexchangestore
-- ----------------------------
DROP TABLE IF EXISTS `store_avatarexchangestore`;
CREATE TABLE `store_avatarexchangestore`  (
  `AvatarId` bigint(20) NOT NULL,
  `DayExchanges` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `WeekExchanges` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `MonthExchanges` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `YearExchanges` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `NoResetExchanges` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for store_randomstore
-- ----------------------------
DROP TABLE IF EXISTS `store_randomstore`;
CREATE TABLE `store_randomstore`  (
  `Id` int(255) NOT NULL COMMENT '商店Id',
  `AvatarId` bigint(20) NOT NULL,
  `CurrentKey` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `FreeRefreshTimes` int(255) NULL DEFAULT NULL,
  `GoldRefreshTimes` int(255) NULL DEFAULT NULL,
  `RefreshTimes` int(255) NULL DEFAULT NULL,
  `RefreshKey` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `CurrentGoods` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`AvatarId`, `Id`) USING BTREE,
  INDEX `ix_store_randomstore_avatarid`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for tasnapshothouse
-- ----------------------------
DROP TABLE IF EXISTS `tasnapshothouse`;
CREATE TABLE `tasnapshothouse`  (
  `AvatarId` bigint(20) NOT NULL COMMENT '玩家Id',
  `HouseBattleDate` int(11) NOT NULL COMMENT '乔迁战斗日期',
  `ServerId` int(11) NOT NULL COMMENT '所属服务器Id',
  `HouseTodayBattleTimes` int(11) NULL DEFAULT NULL COMMENT '乔迁当日乔迁战斗次数',
  `HouseTodayBattleWinTimes` int(11) NULL DEFAULT NULL COMMENT '乔迁当日乔迁成功次数',
  PRIMARY KEY (`AvatarId`, `HouseBattleDate`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for tempbeautystarlv
-- ----------------------------
DROP TABLE IF EXISTS `tempbeautystarlv`;
CREATE TABLE `tempbeautystarlv`  (
  `AvatarId` bigint(20) NOT NULL,
  `Id` int(11) NOT NULL,
  `StarLv` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`, `Id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for templefair
-- ----------------------------
DROP TABLE IF EXISTS `templefair`;
CREATE TABLE `templefair`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `CompensatedItem` tinyint(1) NOT NULL DEFAULT 0,
  `CompensateItemTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `TempleFair_Index`(`ActivityId`, `ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for templefairavatar
-- ----------------------------
DROP TABLE IF EXISTS `templefairavatar`;
CREATE TABLE `templefairavatar`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `Score` int(11) NULL DEFAULT NULL,
  `RollIndex` int(11) NOT NULL,
  `CellIndex` int(11) NOT NULL,
  `LastScoreTime` datetime NULL DEFAULT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `CurRoundCells` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `TempleFairAvatar_Index`(`ActivityId`, `AvatarId`, `ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 282 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for templefairavatarcolddata
-- ----------------------------
DROP TABLE IF EXISTS `templefairavatarcolddata`;
CREATE TABLE `templefairavatarcolddata`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `Round` int(11) NOT NULL,
  `IsEnd` tinyint(1) NOT NULL DEFAULT 0,
  `RewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `MailRewards` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailTime` datetime NULL DEFAULT NULL,
  `MailCompensateItems` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailCompensateItemTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `TempleFairAvatarColdData_Index`(`ActivityId`, `AvatarId`, `ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 244 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for templefairavatarlog
-- ----------------------------
DROP TABLE IF EXISTS `templefairavatarlog`;
CREATE TABLE `templefairavatarlog`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `Round` int(11) NOT NULL,
  `RollIndex` int(11) NOT NULL,
  `CellIndex` int(11) NOT NULL,
  `UseMyPoint` tinyint(1) NOT NULL DEFAULT 0,
  `RollPoint` int(11) NOT NULL,
  `CellReward` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `RollTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `TempleFairAvatarLog_Index`(`ActivityId`, `AvatarId`, `Round`, `RollIndex`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 61 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for temporderrank
-- ----------------------------
DROP TABLE IF EXISTS `temporderrank`;
CREATE TABLE `temporderrank`  (
  `AvatarId` bigint(20) NOT NULL,
  `ordernum` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `PayloadJson` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for tenmilliongoals
-- ----------------------------
DROP TABLE IF EXISTS `tenmilliongoals`;
CREATE TABLE `tenmilliongoals`  (
  `AvatarId` bigint(20) NOT NULL,
  `CurValue` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  `EndTime` datetime NULL DEFAULT NULL,
  `RewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailRewards` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for thanksgiving
-- ----------------------------
DROP TABLE IF EXISTS `thanksgiving`;
CREATE TABLE `thanksgiving`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `CompensatedItem` tinyint(1) NOT NULL DEFAULT 0,
  `CompensateItemTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `Thanksgiving_Index`(`ActivityId`, `ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for thanksgivingavatar
-- ----------------------------
DROP TABLE IF EXISTS `thanksgivingavatar`;
CREATE TABLE `thanksgivingavatar`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `Score` int(11) NULL DEFAULT NULL,
  `LastScoreTime` datetime NULL DEFAULT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `ThanksgivingAvatar_Index`(`ActivityId`, `AvatarId`, `ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 378 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for thanksgivingavatarboxlog
-- ----------------------------
DROP TABLE IF EXISTS `thanksgivingavatarboxlog`;
CREATE TABLE `thanksgivingavatarboxlog`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `Round` int(11) NOT NULL,
  `BoxIndex` int(11) NOT NULL,
  `BoxMenuId` int(11) NOT NULL,
  `BoxReward` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `OpenTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `ThanksgivingAvatarBoxLog_Index`(`ActivityId`, `AvatarId`, `Round`, `BoxIndex`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 130 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for thanksgivingavatarcolddata
-- ----------------------------
DROP TABLE IF EXISTS `thanksgivingavatarcolddata`;
CREATE TABLE `thanksgivingavatarcolddata`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `Round` int(11) NOT NULL,
  `NeedOpenBox` int(11) NOT NULL,
  `RewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `RedPacketReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `TaskRewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `MailRewards` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailTime` datetime NULL DEFAULT NULL,
  `MailCompensateItems` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailCompensateItemTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `ThanksgivingAvatarColdData_Index`(`ActivityId`, `AvatarId`, `ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 273 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for thanksgivingavatartask
-- ----------------------------
DROP TABLE IF EXISTS `thanksgivingavatartask`;
CREATE TABLE `thanksgivingavatartask`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `Days` int(11) NOT NULL,
  `TaskId` int(11) NOT NULL,
  `TaskProgress` int(11) NOT NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  UNIQUE INDEX `ThanksgivingAvatarTask_Index`(`ActivityId`, `AvatarId`, `TaskId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for timeremail
-- ----------------------------
DROP TABLE IF EXISTS `timeremail`;
CREATE TABLE `timeremail`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `SendType` tinyint(4) NOT NULL,
  `EmailType` tinyint(4) NOT NULL,
  `SendTo` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `NoSendTo` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TemplateId` int(11) NULL DEFAULT NULL,
  `ParamList` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `Rewards` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `Title` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Content` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `SendState` tinyint(4) NULL DEFAULT NULL,
  `STime` datetime NULL DEFAULT NULL,
  `ETime` datetime NULL DEFAULT NULL,
  `CreateTime` datetime NULL DEFAULT NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  `SendResult` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 200 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for tradewarbase
-- ----------------------------
DROP TABLE IF EXISTS `tradewarbase`;
CREATE TABLE `tradewarbase`  (
  `Id` bigint(20) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `TradeWarType` int(11) NULL DEFAULT NULL,
  `UseItemId` int(11) NULL DEFAULT NULL,
  `BattleTimes` int(11) NULL DEFAULT NULL,
  `SendAddtion` int(11) NULL DEFAULT NULL COMMENT '派遣加成',
  `EnemyId` bigint(20) NULL DEFAULT NULL,
  `ChaseId` bigint(20) NULL DEFAULT NULL COMMENT '通缉Id',
  `Enemys` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '仇人信息',
  `LastEnemyId` bigint(20) NULL DEFAULT NULL,
  `RandomBattleTimes` int(11) NULL DEFAULT NULL,
  `LastUpdateTime` datetime NULL DEFAULT NULL,
  `BattleStartTime` datetime NULL DEFAULT NULL,
  `BattleHeros` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `RapidTeam` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `ix_tradewarbase_key`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for tradewarchase
-- ----------------------------
DROP TABLE IF EXISTS `tradewarchase`;
CREATE TABLE `tradewarchase`  (
  `Id` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `CreateTime` datetime NULL DEFAULT NULL,
  `ChaseEnemyId` bigint(20) NULL DEFAULT NULL,
  `ChaseState` int(11) NULL DEFAULT NULL,
  `ChasePlayers` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `ix_tradewarchase_key`(`Id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for tradewarhero
-- ----------------------------
DROP TABLE IF EXISTS `tradewarhero`;
CREATE TABLE `tradewarhero`  (
  `Id` bigint(20) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `RandomBattle` int(11) NULL DEFAULT NULL COMMENT '商战随机战斗次数',
  `RandomBattelCoolingTime` datetime NULL DEFAULT NULL COMMENT '随机战斗冷却时间',
  `NoticeOrFightBackBattle` int(11) NULL DEFAULT NULL COMMENT '剩余挑战战斗次数 （公告战斗 反击战斗）',
  PRIMARY KEY (`AvatarId`, `Id`) USING BTREE,
  INDEX `ix_tradewarhero_avatarId`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for tradewarlog
-- ----------------------------
DROP TABLE IF EXISTS `tradewarlog`;
CREATE TABLE `tradewarlog`  (
  `Id` bigint(20) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `BattleTime` bigint(20) NULL DEFAULT NULL,
  `EnemyId` bigint(20) NULL DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Head` int(11) NULL DEFAULT NULL,
  `HeadFrame` int(11) NULL DEFAULT NULL,
  `Lv` int(11) NULL DEFAULT NULL,
  `Addr` int(11) NULL DEFAULT NULL,
  `TardeWarType` int(11) NULL DEFAULT NULL,
  `DefeatHeroCount` int(11) NULL DEFAULT NULL,
  `DeductScore` bigint(20) NULL DEFAULT NULL,
  `NoticeId` int(11) NULL DEFAULT NULL COMMENT '公告Id',
  `IsAdowa` tinyint(4) NULL DEFAULT NULL,
  `IsOut` tinyint(4) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`, `Id`) USING BTREE,
  INDEX `ix_tradewarlog_key`(`Id`, `AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for tradewarrank
-- ----------------------------
DROP TABLE IF EXISTS `tradewarrank`;
CREATE TABLE `tradewarrank`  (
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `Score` double NULL DEFAULT NULL,
  `RankTime` datetime(2) NULL DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Level` int(11) NULL DEFAULT NULL,
  `HeadId` int(11) NULL DEFAULT NULL,
  `HeadFrameId` int(11) NULL DEFAULT NULL,
  `VipLevel` int(11) NULL DEFAULT NULL,
  `AddressId` int(11) NULL DEFAULT NULL,
  `TitleId` int(11) NULL DEFAULT NULL,
  `Image` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  UNIQUE INDEX `ix_routerank_key`(`AvatarId`) USING BTREE,
  INDEX `ix_routerank_serverid`(`ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for universalactivity
-- ----------------------------
DROP TABLE IF EXISTS `universalactivity`;
CREATE TABLE `universalactivity`  (
  `ActivityId` int(11) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `CompensatedItem` tinyint(1) NULL DEFAULT NULL,
  `CompensateItemTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`ActivityId`, `ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for universalactivityavatar
-- ----------------------------
DROP TABLE IF EXISTS `universalactivityavatar`;
CREATE TABLE `universalactivityavatar`  (
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `Score` int(11) NULL DEFAULT NULL,
  `LastScoreTime` datetime NULL DEFAULT NULL,
  `LastBuyTime` datetime NULL DEFAULT NULL,
  `BuyItems` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DailyResetTime` datetime NULL DEFAULT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `RewardReceive` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MailRewards` varchar(5000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MailTime` datetime NULL DEFAULT NULL,
  `MailCompensateItems` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailCompensateItemTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`ActivityId`, `AvatarId`, `ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for unlockdialogboxrecord
-- ----------------------------
DROP TABLE IF EXISTS `unlockdialogboxrecord`;
CREATE TABLE `unlockdialogboxrecord`  (
  `AvatarId` bigint(20) NOT NULL,
  `DialogBoxId` int(11) NOT NULL,
  UNIQUE INDEX `UnlockDialogBoxRecord_Index`(`AvatarId`, `DialogBoxId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for wateringlog
-- ----------------------------
DROP TABLE IF EXISTS `wateringlog`;
CREATE TABLE `wateringlog`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ActivityId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `FromAvatarId` bigint(20) NOT NULL,
  `FromName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `MsgId` int(11) NOT NULL,
  `WarteringTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `WateringLog_Index`(`ActivityId`, `AvatarId`, `FromAvatarId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for wboss_serverrankhistory
-- ----------------------------
DROP TABLE IF EXISTS `wboss_serverrankhistory`;
CREATE TABLE `wboss_serverrankhistory`  (
  `Id` bigint(11) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `RankJson` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  PRIMARY KEY (`Id`, `ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for wbossavatar
-- ----------------------------
DROP TABLE IF EXISTS `wbossavatar`;
CREATE TABLE `wbossavatar`  (
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `AtkScore` bigint(20) NULL DEFAULT NULL,
  `FightDate` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `UpdateTime` datetime NULL DEFAULT NULL,
  `FightedHeros` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for wbossserver
-- ----------------------------
DROP TABLE IF EXISTS `wbossserver`;
CREATE TABLE `wbossserver`  (
  `ServerId` int(11) NOT NULL,
  `BossId` int(11) NOT NULL,
  `KilledTimes` int(11) NOT NULL,
  `FightDate` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `LeftHp` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `TotalHp` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `IsKilled` tinyint(1) NULL DEFAULT NULL,
  `KilledTime` bigint(20) NULL DEFAULT NULL,
  `KillPlayer` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for wealthtree
-- ----------------------------
DROP TABLE IF EXISTS `wealthtree`;
CREATE TABLE `wealthtree`  (
  `ActivityId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `CompensatedItem` tinyint(1) NOT NULL DEFAULT 0,
  `CompensateItemTime` datetime NULL DEFAULT NULL,
  UNIQUE INDEX `WealthTree_Index`(`ActivityId`, `ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for wealthtreeavatar
-- ----------------------------
DROP TABLE IF EXISTS `wealthtreeavatar`;
CREATE TABLE `wealthtreeavatar`  (
  `AvatarId` bigint(20) NOT NULL,
  `ActivityId` int(11) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `Score` bigint(20) NOT NULL,
  `LastScoreTime` datetime NULL DEFAULT NULL,
  `HelpCount` int(11) NOT NULL,
  `DailyHelpList` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `DailyWateringDic` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `DailyResetTime` datetime NULL DEFAULT NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  UNIQUE INDEX `WealthTreeAvatar_Index`(`AvatarId`, `ActivityId`, `ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for wealthtreeavatarcolddata
-- ----------------------------
DROP TABLE IF EXISTS `wealthtreeavatarcolddata`;
CREATE TABLE `wealthtreeavatarcolddata`  (
  `AvatarId` bigint(20) NOT NULL,
  `ActivityId` int(11) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `TaskRewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `HelpRewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `RewardReceive` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ResetTime` datetime NULL DEFAULT NULL,
  `MailRewards` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailTime` datetime NULL DEFAULT NULL,
  `MailCompensateItems` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MailCompensateItemTime` datetime NULL DEFAULT NULL,
  UNIQUE INDEX `WealthTreeAvatarColdData_Index`(`AvatarId`, `ActivityId`, `ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for yzroledata
-- ----------------------------
DROP TABLE IF EXISTS `yzroledata`;
CREATE TABLE `yzroledata`  (
  `RoleId` bigint(20) NOT NULL,
  `RoleType` int(11) NULL DEFAULT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `ClientIp` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Device` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Account` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `AdId` int(11) NULL DEFAULT NULL,
  `PtAccountRegtime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ChannelId` int(11) NULL DEFAULT NULL,
  `MultiscreenType` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `SpareOne` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `BundleId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Model` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Country` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Region` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Language` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `YZDeviceId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Oaid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `SdkVer` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `OpSid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `OpId` int(11) NULL DEFAULT NULL,
  `OpGameId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`RoleId`) USING BTREE,
  INDEX `RoleIdKey`(`RoleId`) USING BTREE,
  INDEX `ServerIdKey`(`ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for yzrolepaydata
-- ----------------------------
DROP TABLE IF EXISTS `yzrolepaydata`;
CREATE TABLE `yzrolepaydata`  (
  `AvatarId` bigint(20) NOT NULL,
  `DailyPayDiamond` bigint(20) NULL DEFAULT NULL,
  `MaxDailyPayDiamond` bigint(20) NULL DEFAULT NULL,
  `MaxSinglePayDiamond` bigint(20) NULL DEFAULT NULL,
  `TotalPayDiamond` bigint(20) NULL DEFAULT NULL,
  `TotalPayDays` bigint(20) NULL DEFAULT NULL,
  `FirstPayDiamond` bigint(20) NULL DEFAULT NULL,
  `FirstPayTime` bigint(20) NULL DEFAULT NULL,
  `LastPayTime` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for z_bosswayrecord
-- ----------------------------
DROP TABLE IF EXISTS `z_bosswayrecord`;
CREATE TABLE `z_bosswayrecord`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `FightDate` bigint(20) NULL DEFAULT NULL,
  `DailyScore` bigint(20) NULL DEFAULT NULL,
  `TotalScore` bigint(20) NULL DEFAULT NULL,
  `TimeStamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for z_prop202208
-- ----------------------------
DROP TABLE IF EXISTS `z_prop202208`;
CREATE TABLE `z_prop202208`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `PropId` int(11) NULL DEFAULT NULL,
  `ChangeBefore` bigint(20) NULL DEFAULT NULL,
  `ChangeAmount` bigint(20) NULL DEFAULT NULL,
  `ChangeAfter` bigint(20) NULL DEFAULT NULL,
  `Reason` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `TimeStamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 251 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for z_prop202209
-- ----------------------------
DROP TABLE IF EXISTS `z_prop202209`;
CREATE TABLE `z_prop202209`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `PropId` int(11) NULL DEFAULT NULL,
  `ChangeBefore` bigint(20) NULL DEFAULT NULL,
  `ChangeAmount` bigint(20) NULL DEFAULT NULL,
  `ChangeAfter` bigint(20) NULL DEFAULT NULL,
  `Reason` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `TimeStamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3133 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for z_prop202210
-- ----------------------------
DROP TABLE IF EXISTS `z_prop202210`;
CREATE TABLE `z_prop202210`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `PropId` int(11) NULL DEFAULT NULL,
  `ChangeBefore` bigint(20) NULL DEFAULT NULL,
  `ChangeAmount` bigint(20) NULL DEFAULT NULL,
  `ChangeAfter` bigint(20) NULL DEFAULT NULL,
  `Reason` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `TimeStamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for z_wbossrecord
-- ----------------------------
DROP TABLE IF EXISTS `z_wbossrecord`;
CREATE TABLE `z_wbossrecord`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NULL DEFAULT NULL,
  `ServerId` int(11) NULL DEFAULT NULL,
  `FightDate` bigint(20) NULL DEFAULT NULL,
  `AtkScore` bigint(20) NULL DEFAULT NULL,
  `TimeStamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Procedure structure for ClearStorage
-- ----------------------------
DROP PROCEDURE IF EXISTS `ClearStorage`;
delimiter ;;
CREATE PROCEDURE `ClearStorage`(in _GrainIdHash INT,
    in _GrainIdN0 BIGINT,
    in _GrainIdN1 BIGINT,
    in _GrainTypeHash INT,
    in _GrainTypeString NVARCHAR(512),
    in _GrainIdExtensionString NVARCHAR(512),
    in _ServiceId NVARCHAR(150),
    in _GrainStateVersion INT)
BEGIN
    DECLARE _newGrainStateVersion INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
    DECLARE EXIT HANDLER FOR SQLWARNING BEGIN ROLLBACK; RESIGNAL; END;

    SET _newGrainStateVersion = _GrainStateVersion;

    -- Default level is REPEATABLE READ and may cause Gap Lock issues
    SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    START TRANSACTION;
    UPDATE OrleansStorage
    SET
        PayloadBinary = NULL,
        PayloadJson = NULL,
        PayloadXml = NULL,
        Version = Version + 1
    WHERE
        GrainIdHash = _GrainIdHash AND _GrainIdHash IS NOT NULL
        AND GrainTypeHash = _GrainTypeHash AND _GrainTypeHash IS NOT NULL
        AND GrainIdN0 = _GrainIdN0 AND _GrainIdN0 IS NOT NULL
        AND GrainIdN1 = _GrainIdN1 AND _GrainIdN1 IS NOT NULL
        AND GrainTypeString = _GrainTypeString AND _GrainTypeString IS NOT NULL
        AND ((_GrainIdExtensionString IS NOT NULL AND GrainIdExtensionString IS NOT NULL AND GrainIdExtensionString = _GrainIdExtensionString) OR _GrainIdExtensionString IS NULL AND GrainIdExtensionString IS NULL)
        AND ServiceId = _ServiceId AND _ServiceId IS NOT NULL
        AND Version IS NOT NULL AND Version = _GrainStateVersion AND _GrainStateVersion IS NOT NULL
        LIMIT 1;

    IF ROW_COUNT() > 0
    THEN
        SET _newGrainStateVersion = _GrainStateVersion + 1;
    END IF;

    SELECT _newGrainStateVersion AS NewGrainStateVersion;
    COMMIT;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for CreateTable
-- ----------------------------
DROP PROCEDURE IF EXISTS `CreateTable`;
delimiter ;;
CREATE PROCEDURE `CreateTable`(in _GrainTypeString NVARCHAR(512))
BEGIN
set @sql_create_table = concat('CREATE TABLE IF NOT EXISTS `',_GrainTypeString,'`',
 "(
    GrainIdHash                INT NOT NULL,
    GrainIdN0                BIGINT NOT NULL,
    GrainIdN1                BIGINT NOT NULL,
    GrainTypeHash            INT NOT NULL,
    GrainTypeString            NVARCHAR(512) NOT NULL,
    GrainIdExtensionString    NVARCHAR(512) NULL,
    ServiceId                NVARCHAR(150) NOT NULL,
    PayloadBinary    BLOB NULL,
    PayloadXml        LONGTEXT NULL,
    PayloadJson        LONGTEXT NULL,
    ModifiedOn DATETIME NOT NULL,
    Version INT NULL,
		INDEX `IX_",_GrainTypeString,"`(GrainIdHash, GrainTypeHash)
) ROW_FORMAT = COMPRESSED KEY_BLOCK_SIZE = 16;");
PREPARE sql_create_table FROM @sql_create_table;
EXECUTE sql_create_table;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for load_avatar
-- ----------------------------
DROP PROCEDURE IF EXISTS `load_avatar`;
delimiter ;;
CREATE PROCEDURE `load_avatar`(in id BIGINT(20))
BEGIN
	select * from achievement   where avatarid = id;
	select * from activityitemcomposite where avatarid = id;
	select * from activitylimitsignin   where avatarid = id;
	select * from activitylimittask where avatarid = id;
	select * from activityrecharge  where avatarid = id;
	select * from assignment    where avatarid = id;
	select * from assignmentprogress    where avatarid = id;
	select * from avatarbank    where avatarid = id;
	select * from avatarbase    where avatarid = id;
	select * from avatarbeauties    where avatarid = id;
	select * from avatarcolddata    where avatarid = id;
	select * from avatarcurrency    where avatarid = id;
	select * from avataremail   where avatarid = id;
	select * from avatarfirstpack   where avatarid = id;
	select * from avatargoldstores  where avatarid = id;
	select * from avatarheros   where avatarid = id;
	select * from avatarhotdata where avatarid = id;
	select * from avatarillustrated where avatarid = id;
	select * from avatarinlaws  where avatarid = id;
	select * from avatarinlawsletter    where avatarid = id;
	select * from avatarkid where avatarid = id;
	select * from avatarkidbase where avatarid = id;
	select * from avatarkidplace    where avatarid = id;
	select * from avatarpet where avatarid = id;
	select * from avatarpoppack where avatarid = id;
	select * from avatarprivilegecard   where avatarid = id;
	select * from avatarrechargebase    where avatarid = id;
	select * from avatarroutebase   where avatarid = id;
	select * from avatarscore   where avatarid = id;
	select * from avatarship    where avatarid = id;
	select * from avatarshiproute   where avatarid = id;
	select * from avatarshop    where avatarid = id;
	select * from avatarshopbase    where avatarid = id;
	select * from avatarstoreexchangehistory    where avatarid = id;
	select * from avatartitle   where avatarid = id;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for new_procedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `new_procedure`;
delimiter ;;
CREATE PROCEDURE `new_procedure`()
BEGIN
		DECLARE json_items BIGINT DEFAULT 0;
		DECLARE _index BIGINT DEFAULT 0;
		DECLARE flag INT DEFAULT 0;
		DECLARE info VARCHAR(2000);
		DECLARE avatarInfo VARCHAR(2000);
		DECLARE infos CURSOR FOR SELECT payloadJson FROM `sailina.tang.player.avatar.`;
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET flag = 1;
		OPEN infos;
			FETCH infos INTO info;
			WHILE flag != 1 DO
				set json_items = JSON_LENGTH(info);
				set _index =0;
				WHILE _index < json_items DO
					INSERT INTO `jsonTemporary` (`msg`) VALUES (JSON_EXTRACT(info, CONCAT('$[',`_index`,']')));
					SET _index = _index + 1;
				END WHILE;
				FETCH infos INTO info;
			END WHILE;
		CLOSE infos;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ReadAvatar
-- ----------------------------
DROP PROCEDURE IF EXISTS `ReadAvatar`;
delimiter ;;
CREATE PROCEDURE `ReadAvatar`(IN aid bigint)
BEGIN
  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  START TRANSACTION;
	#Routine body goes here...
	SELECT * FROM `avatarbase` WHERE `AvatarId`= aid;
	SELECT * FROM `avatarhotdata` WHERE `AvatarId`=aid;
	SELECT * FROM `avatarcolddata` WHERE `AvatarId`=aid;
	SELECT * FROM `avatarcurrency` WHERE `AvatarId`=aid;
	SELECT * FROM `avatarbank` WHERE `AvatarId`=aid;
	SELECT * FROM `avatarkidbase` WHERE `AvatarId`=aid;
	SELECT * FROM `avatarillustrated` WHERE `AvatarId`=aid;
	SELECT * FROM `avatarshopbase` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarRouteBase` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarFirstPack` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarRechargeBase` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarShopMerchant` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarInLaws` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarInLawsLetter` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarKidPlace` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarTitle` WHERE `AvatarId`=aid;	
	SELECT * FROM `AvatarShop` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarPopPack` WHERE `AvatarId`=aid;	
	SELECT * FROM `ActivityRecharge` WHERE `AvatarId`=aid;	
	COMMIT;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ReadAvatarExtend
-- ----------------------------
DROP PROCEDURE IF EXISTS `ReadAvatarExtend`;
delimiter ;;
CREATE PROCEDURE `ReadAvatarExtend`(IN aid bigint)
BEGIN
  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  START TRANSACTION;	
	#Routine body goes here...
	SELECT * FROM `TradeWarBase` WHERE `AvatarId`= aid;
	SELECT * FROM `TradeWarLog` WHERE `AvatarId`= aid;
	SELECT * FROM `TradewarHero` WHERE `AvatarId`= aid;
	SELECT * FROM `Assignment` WHERE `AvatarId`= aid;
	SELECT * FROM `AssignmentProgress` WHERE `AvatarId`= aid;	
	SELECT * FROM `Achievement` WHERE `AvatarId`= aid;		
	COMMIT;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ReadAvatar_1
-- ----------------------------
DROP PROCEDURE IF EXISTS `ReadAvatar_1`;
delimiter ;;
CREATE PROCEDURE `ReadAvatar_1`(IN aid bigint)
BEGIN
  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  START TRANSACTION;
	#Routine body goes here...
	SELECT * FROM `avatarbase` WHERE `AvatarId`= aid;
	SELECT * FROM `avatarhotdata` WHERE `AvatarId`=aid;
	SELECT * FROM `avatarcolddata` WHERE `AvatarId`=aid;
	SELECT * FROM `avatarcurrency` WHERE `AvatarId`=aid;
	
	SELECT * FROM `avatarbank` WHERE `AvatarId`=aid;
	SELECT * FROM `avatarshopbase` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarShopMerchant` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarShop` WHERE `AvatarId`=aid;
	
	SELECT * FROM `avatarkidbase` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarKidPlace` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarInLaws` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarInLawsLetter` WHERE `AvatarId`=aid;	
	SELECT * FROM `AvatarKid` WHERE `AvatarId`=aid;	
	
	SELECT * FROM `AvatarRouteBase` WHERE `AvatarId`=aid;	
	SELECT * FROM `AvatarShipRoute` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarShip` WHERE `AvatarId`=aid;
	SELECT * FROM `TradeWarBase` WHERE `AvatarId`=aid;
	SELECT * FROM `TradeWarLog` WHERE `AvatarId`=aid;
	SELECT * FROM `TradewarHero` WHERE `AvatarId`=aid;
	
	SELECT * FROM `AvatarFirstPack` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarGoldStores` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarRechargeBase` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarPopPack` WHERE `AvatarId`=aid;
	SELECT * FROM `ActivityRecharge` WHERE `AvatarId`=aid;
	
	SELECT * FROM `Assignment` WHERE `AvatarId`=aid;
	SELECT * FROM `AssignmentProgress` WHERE `AvatarId`=aid;
	SELECT * FROM `Achievement` WHERE `AvatarId`=aid;
	
	SELECT * FROM `AvatarTitle` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarIllustrated` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarTravel` WHERE `AvatarId`=aid;
	SELECT * FROM `AvatarPet` WHERE `AvatarId`=aid;
	
	COMMIT;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ReadStorage
-- ----------------------------
DROP PROCEDURE IF EXISTS `ReadStorage`;
delimiter ;;
CREATE PROCEDURE `ReadStorage`(in _GrainIdHash INT,
    in _GrainIdN0 BIGINT,
    in _GrainIdN1 BIGINT,
    in _GrainTypeHash INT,
    in _GrainTypeString NVARCHAR(512),
    in _GrainIdExtensionString NVARCHAR(512),
    in _ServiceId NVARCHAR(150))
BEGIN
	CALL CreateTable(_GrainTypeString);
	#Routine body goes here...
set @read_sql= concat("SELECT
        PayloadBinary,
        PayloadXml,
        PayloadJson,
        UTC_TIMESTAMP(),
        Version
    FROM
        `",_GrainTypeString,"`    WHERE
        GrainIdHash = @GrainIdHash
        AND GrainTypeHash = @GrainTypeHash AND @GrainTypeHash IS NOT NULL
        AND GrainIdN0 = @GrainIdN0 AND @GrainIdN0 IS NOT NULL
        AND GrainIdN1 = @GrainIdN1 AND @GrainIdN1 IS NOT NULL
        AND GrainTypeString = @GrainTypeString AND GrainTypeString IS NOT NULL
        AND ((@GrainIdExtensionString IS NOT NULL AND GrainIdExtensionString IS NOT NULL AND GrainIdExtensionString = @GrainIdExtensionString) OR @GrainIdExtensionString IS NULL AND GrainIdExtensionString IS NULL)
        AND ServiceId = @ServiceId AND @ServiceId IS NOT NULL
        LIMIT 1;");
				set  @GrainIdHash =_GrainIdHash,@GrainIdN0=_GrainIdN0,@GrainIdN1=_GrainIdN1,@GrainTypeHash =_GrainTypeHash,@GrainTypeString =_GrainTypeString,@GrainIdExtensionString =_GrainIdExtensionString,@ServiceId =_ServiceId;
				PREPARE read_sql FROM @read_sql;  
				EXECUTE read_sql;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for RemoveAvatar
-- ----------------------------
DROP PROCEDURE IF EXISTS `RemoveAvatar`;
delimiter ;;
CREATE PROCEDURE `RemoveAvatar`(IN `aid` bigint)
BEGIN
	#Routine body goes here...

END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for TempTable1
-- ----------------------------
DROP PROCEDURE IF EXISTS `TempTable1`;
delimiter ;;
CREATE PROCEDURE `TempTable1`()
BEGIN

	DECLARE _c1 int DEFAULT 0;
	
	DROP TABLE IF EXISTS `activityexchange`;
	DROP TABLE IF EXISTS `banquet_avatarv2`;
	DROP TABLE IF EXISTS `sailina.tang.player.avatarcsm`;
	DROP TABLE IF EXISTS `sailina.tang.common.selfincreasing`;
	DROP TABLE IF EXISTS `sailina.tang.player.wbossavatar.extend`;
	DROP TABLE IF EXISTS `sailina.tang.player.wbossserver`;
	DROP TABLE IF EXISTS `sailina.tang.player.avatar.avatarvipstate`;
	DROP TABLE IF EXISTS `sailina.tang.player.avatar.avatarbeautiesstate`;
	DROP TABLE IF EXISTS `sailina.tang.player.avatar.avatarvisit`;
	DROP TABLE IF EXISTS `sailina.tang.player.avatarrank`;
	
	
	select count(*) into _c1 from information_schema.columns where table_schema=database() and table_name = 'day7base' and column_name = 'GrainIdN1';
	if _c1>0 
	THEN
		DROP TABLE IF EXISTS `day7base`;
	END IF;
	
	
	select count(*) into _c1 from information_schema.columns where table_schema=database() and table_name = 'house_avatarhouselog' and column_name = 'GrainIdN1';
	if _c1>0 
	THEN
		DROP TABLE IF EXISTS `house_avatarhouselog`;
	END IF;
	
	
	select count(*) into _c1 from information_schema.columns where table_schema=database() and table_name = 'store_activityexchange' and column_name = 'GrainIdN1';
	if _c1>0 
	THEN
		DROP TABLE IF EXISTS `store_activityexchange`;
	END IF;
	
	
	select count(*) into _c1 from information_schema.columns where table_schema=database() and table_name = 'store_avatarexchangestore' and column_name = 'GrainIdN1';
	if _c1=1 
	THEN
		DROP TABLE IF EXISTS `store_avatarexchangestore`;
	END IF;
	

	select count(*) into _c1 from information_schema.columns where table_schema=database() and table_name = 'wbossavatar' and column_name = 'FightedHeros';
	if _c1=0 
	THEN
		ALTER TABLE `wbossavatar` 
		ADD COLUMN `FightedHeros` text NULL AFTER `UpdateTime`;
	END IF;

	select count(*) into _c1 from information_schema.columns where table_schema=database() and table_name = 'wbossavatar' and column_name = 'Id';
	if _c1>0 
	THEN
		ALTER TABLE `wbossavatar` 
		DROP COLUMN `Id`;
	END IF;

END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for WriteToStorage
-- ----------------------------
DROP PROCEDURE IF EXISTS `WriteToStorage`;
delimiter ;;
CREATE PROCEDURE `WriteToStorage`(in _GrainIdHash INT,
    in _GrainIdN0 BIGINT,
    in _GrainIdN1 BIGINT,
    in _GrainTypeHash INT,
    in _GrainTypeString NVARCHAR(512),
    in _GrainIdExtensionString NVARCHAR(512),
    in _ServiceId NVARCHAR(150),
    in _GrainStateVersion INT,
    in _PayloadBinary BLOB,
    in _PayloadJson LONGTEXT,
    in _PayloadXml LONGTEXT)
BEGIN
    DECLARE _newGrainStateVersion INT;
    DECLARE _rowCount INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
    DECLARE EXIT HANDLER FOR SQLWARNING BEGIN ROLLBACK; RESIGNAL; END;

    -- Default level is REPEATABLE READ and may cause Gap Lock issues
    SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    
    START TRANSACTION;
    -- CALL CreateTable(_GrainTypeString);
    -- Grain state is not null, so the state must have been read from the storage before.
    -- Let's try to update it.
    --
    -- When Orleans is running in normal, non-split state, there will
    -- be only one grain with the given ID and type combination only. This
    -- grain saves states mostly serially if Orleans guarantees are upheld. Even
    -- if not, the updates should work correctly due to version number.
    --
    -- In split brain situations there can be a situation where there are two or more
    -- grains with the given ID and type combination. When they try to INSERT
    -- concurrently, the table needs to be locked pessimistically before one of
    -- the grains gets @GrainStateVersion = 1 in return and the other grains will fail
    -- to update storage. The following arrangement is made to reduce locking in normal operation.
    --
    -- If the version number explicitly returned is still the same, Orleans interprets it so the update did not succeed
    -- and throws an InconsistentStateException.
    --
    -- See further information at https://dotnet.github.io/orleans/Documentation/Core-Features/Grain-Persistence.html.
    IF _GrainStateVersion IS NOT NULL
    THEN
        SET @update_sql=concat("UPDATE  `",_GrainTypeString,"`
        SET
            PayloadBinary = @PayloadBinary,
            PayloadJson = @PayloadJson,
            PayloadXml = @PayloadXml,
            ModifiedOn = UTC_TIMESTAMP(),
            Version = Version + 1
        WHERE
            GrainIdHash = @GrainIdHash 
            AND GrainTypeHash = @GrainTypeHash 
            AND GrainIdN0 = @GrainIdN0 
            AND GrainIdN1 = @GrainIdN1 
            AND GrainTypeString = @GrainTypeString 
            AND ServiceId = @ServiceId
            LIMIT 1;");
				set  @GrainIdHash =_GrainIdHash,@GrainIdN0=_GrainIdN0,@GrainIdN1=_GrainIdN1,@GrainTypeHash =_GrainTypeHash,@GrainTypeString =_GrainTypeString,@GrainIdExtensionString =_GrainIdExtensionString,@ServiceId =_ServiceId;
				set  @GrainStateVersion =_GrainStateVersion,@PayloadBinary =_PayloadBinary ,    @PayloadJson =_PayloadJson ,    @PayloadXml =_PayloadXml ;
				PREPARE update_sql FROM @update_sql;  
				EXECUTE update_sql;
    END IF;

    -- The grain state has not been read. The following locks rather pessimistically
    -- to ensure only on INSERT succeeds.
    IF _GrainStateVersion IS NULL
    THEN
        SET @insert_sql=concat("INSERT INTO `",_GrainTypeString,"`
        (
            GrainIdHash,
            GrainIdN0,
            GrainIdN1,
            GrainTypeHash,
            GrainTypeString,
            GrainIdExtensionString,
            ServiceId,
            PayloadBinary,
            PayloadJson,
            PayloadXml,
            ModifiedOn,
            Version
        )
        SELECT * FROM ( SELECT
            @GrainIdHash,
            @GrainIdN0,
            @GrainIdN1,
            @GrainTypeHash,
            @GrainTypeString,
            @GrainIdExtensionString,
            @ServiceId,
            @PayloadBinary,
            @PayloadJson,
            @PayloadXml,
            UTC_TIMESTAMP(),
            1) AS TMP
        WHERE NOT EXISTS
        (
            -- There should not be any version of this grain state.
            SELECT 1
            FROM `",_GrainTypeString,"`
            WHERE
            GrainIdHash = @GrainIdHash
            AND GrainTypeHash = @GrainTypeHash
            AND GrainIdN0 = @GrainIdN0
            AND GrainIdN1 = @GrainIdN1
            AND GrainTypeString = @GrainTypeString
            AND ((@GrainIdExtensionString IS NOT NULL AND GrainIdExtensionString IS NOT NULL AND GrainIdExtensionString = @GrainIdExtensionString) 
								OR @GrainIdExtensionString IS NULL AND GrainIdExtensionString IS NULL)
            AND ServiceId = @ServiceId AND @ServiceId IS NOT NULL
        ) LIMIT 1;");
				set  @GrainIdHash =_GrainIdHash,@GrainIdN0=_GrainIdN0,@GrainIdN1=_GrainIdN1,@GrainTypeHash =_GrainTypeHash,@GrainTypeString =_GrainTypeString,@GrainIdExtensionString =_GrainIdExtensionString,@ServiceId =_ServiceId;
				set  @PayloadBinary =_PayloadBinary ,    @PayloadJson =_PayloadJson ,    @PayloadXml =_PayloadXml ;
				PREPARE insert_sql FROM @insert_sql;  
				EXECUTE insert_sql;
    END IF;
		COMMIT;
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
