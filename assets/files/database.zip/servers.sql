/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50731
 Source Host           : localhost:3306
 Source Schema         : ucenter

 Target Server Type    : MySQL
 Target Server Version : 50731
 File Encoding         : 65001

 Date: 04/02/2024 17:46:54
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for servers
-- ----------------------------
DROP TABLE IF EXISTS `servers`;
CREATE TABLE `servers`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `IsVisiable` tinyint(1) NOT NULL,
  `CanRegister` tinyint(1) NOT NULL DEFAULT 0,
  `CreateDate` datetime(6) NOT NULL DEFAULT '0001-01-01 00:00:00.000000',
  `IsDeleted` tinyint(1) NOT NULL DEFAULT 0,
  `LastMaintenanceDate` datetime(6) NOT NULL DEFAULT '0001-01-01 00:00:00.000000',
  `Status` int(11) NOT NULL DEFAULT 0,
  `Tags` int(11) NOT NULL DEFAULT 0,
  `OpenTime` datetime(6) NOT NULL,
  `Group` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `OpSid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10000 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of servers
-- ----------------------------
INSERT INTO `servers` VALUES (1, '长安东市一区', 1, 1, '2021-08-09 09:38:53.000000', 0, '2021-08-09 09:38:45.000000', 1, 1, '2021-08-09 00:00:00.000000', '长安东市', '10000000001');
INSERT INTO `servers` VALUES (2, '长安东市二区', 1, 1, '2021-08-09 09:38:51.000000', 0, '2021-08-09 09:38:43.000000', 2, 1, '2022-01-07 00:00:00.000000', '长安东市', '10000000002');
INSERT INTO `servers` VALUES (3, '长安东市三区', 1, 1, '2021-08-09 09:38:50.000000', 0, '2021-08-09 09:38:41.000000', 2, 1, '2021-08-09 00:00:00.000000', '长安东市', '10000000003');
INSERT INTO `servers` VALUES (4, '长安东市四区', 1, 1, '2021-08-09 09:38:48.000000', 0, '2021-08-09 09:38:38.000000', 1, 1, '2021-11-12 08:00:00.000000', '长安东市', '10000000004');
INSERT INTO `servers` VALUES (5, '长安东市五区', 1, 1, '2021-08-03 18:15:41.602374', 0, '2021-08-03 18:15:41.602378', 1, 1, '2021-08-09 10:37:04.000000', '长安东市', '10000000005');
INSERT INTO `servers` VALUES (6, '长安西市一区', 1, 1, '2021-08-20 15:27:20.000000', 0, '2021-08-20 15:27:25.000000', 1, 0, '2021-08-31 15:27:31.000000', '长安西市', '10000000006');
INSERT INTO `servers` VALUES (7, '长安西市二区', 1, 1, '2021-09-09 00:00:00.000000', 0, '2021-09-09 00:00:00.000000', 1, 1, '2021-09-09 00:00:00.000000', '长安西市', '10000000007');
INSERT INTO `servers` VALUES (8, '长安西市三区', 1, 1, '2021-11-11 14:29:49.210348', 0, '2021-11-11 14:29:49.210349', 1, 1, '2021-11-18 14:29:49.210351', '长安西市', '10000000008');
INSERT INTO `servers` VALUES (9, '长安西市四区', 1, 1, '2021-11-11 15:04:56.435606', 0, '2021-11-11 15:04:56.435607', 1, 2, '2021-11-18 15:04:56.435609', '长安西市', '10000000009');
INSERT INTO `servers` VALUES (10, '长安西市五区', 1, 1, '2021-12-22 11:55:23.000000', 0, '2021-12-22 11:55:26.000000', 3, 1, '2021-12-22 11:55:30.000000', '长安西市', '10000000010');
INSERT INTO `servers` VALUES (100, '测试服1', 1, 1, '2022-01-14 14:27:31.870334', 0, '2022-01-14 14:27:31.870334', 1, 3, '2022-01-14 00:00:00.000000', '长安西市', '10000000101');
INSERT INTO `servers` VALUES (1009, '测试区服', 0, 0, '2022-08-19 14:19:42.937342', 0, '2022-08-19 14:19:42.937343', 1, 0, '2022-08-31 00:00:00.000000', '长安东市', '10000005005');
INSERT INTO `servers` VALUES (5001, '长安东市二三', 0, 1, '2021-12-22 11:50:19.000000', 1, '2021-12-22 11:50:23.000000', 3, 1, '2021-12-21 11:50:26.000000', '看不见我', '10000005001');
INSERT INTO `servers` VALUES (5002, '测试2服', 0, 0, '2022-01-06 21:33:02.391948', 1, '2022-01-06 21:33:02.391948', 1, 0, '2022-01-07 00:00:00.000000', '新测试群组', '10000005002');
INSERT INTO `servers` VALUES (5003, '测试长安东市', 0, 0, '2022-08-13 23:41:23.308915', 0, '2022-08-13 23:41:23.308915', 1, 0, '2022-08-23 00:00:00.000000', '长安东市', '0');
INSERT INTO `servers` VALUES (9999, '9999', 1, 1, '2022-06-06 09:44:49.000000', 0, '2022-06-06 09:44:54.000000', 1, 1, '2022-06-06 09:45:02.000000', '9999', '10000009999');

SET FOREIGN_KEY_CHECKS = 1;
