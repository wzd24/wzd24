/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50731
 Source Host           : localhost:3306
 Source Schema         : tang_chat

 Target Server Type    : MySQL
 Target Server Version : 50731
 File Encoding         : 65001

 Date: 04/02/2024 16:54:58
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for bannedchatsetting
-- ----------------------------
DROP TABLE IF EXISTS `bannedchatsetting`;
CREATE TABLE `bannedchatsetting`  (
  `AvatarId` bigint(20) NOT NULL,
  `ServerId` int(11) NOT NULL,
  `Duration` int(11) NULL DEFAULT NULL,
  `IsPermanent` tinyint(1) NULL DEFAULT NULL,
  `EndTime` datetime NULL DEFAULT NULL,
  `Type` int(11) NULL DEFAULT NULL,
  `Reason` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `un_serverId`(`AvatarId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for banquetchatmessage
-- ----------------------------
DROP TABLE IF EXISTS `banquetchatmessage`;
CREATE TABLE `banquetchatmessage`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ServerId` int(11) NULL DEFAULT NULL,
  `RoleId` bigint(20) NULL DEFAULT NULL,
  `TitleID` int(11) NULL DEFAULT NULL,
  `Vip` int(11) NULL DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Content` varchar(5000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `DeviceId` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `IDFA` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Time` datetime NULL DEFAULT NULL,
  `BanquetId` bigint(20) NULL DEFAULT NULL,
  `Head` int(11) NULL DEFAULT NULL,
  `AddressId` int(11) NULL DEFAULT NULL,
  `HeadFrame` int(11) NULL DEFAULT NULL,
  `Level` int(11) NULL DEFAULT NULL,
  `Img` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `un_serverId`(`ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 44 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for chatblacklist
-- ----------------------------
DROP TABLE IF EXISTS `chatblacklist`;
CREATE TABLE `chatblacklist`  (
  `ServerId` int(11) NOT NULL,
  `AvatarId` bigint(20) NOT NULL,
  `ShieldId` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`AvatarId`) USING BTREE,
  INDEX `un_serverId`(`ServerId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for crossserverchatmessages
-- ----------------------------
DROP TABLE IF EXISTS `crossserverchatmessages`;
CREATE TABLE `crossserverchatmessages`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ServerId` int(11) NULL DEFAULT NULL,
  `ServerGroupId` int(11) NULL DEFAULT NULL,
  `RoleId` bigint(20) NULL DEFAULT NULL,
  `TitleId` int(11) NULL DEFAULT NULL,
  `Vip` int(11) NULL DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Content` varchar(5000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `DeviceId` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `IDFA` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Time` datetime NULL DEFAULT NULL,
  `Head` int(11) NULL DEFAULT NULL,
  `AddressId` int(11) NULL DEFAULT NULL,
  `HeadFrame` int(11) NULL DEFAULT NULL,
  `Level` int(11) NULL DEFAULT NULL,
  `Img` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 42 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for guildchatmessages
-- ----------------------------
DROP TABLE IF EXISTS `guildchatmessages`;
CREATE TABLE `guildchatmessages`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ServerId` int(11) NULL DEFAULT NULL,
  `RoleId` bigint(20) NULL DEFAULT NULL,
  `TitleId` int(11) NULL DEFAULT NULL,
  `Vip` int(11) NULL DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Content` varchar(5000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `DeviceId` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `IDFA` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Time` datetime NULL DEFAULT NULL,
  `GuildId` int(11) NULL DEFAULT NULL,
  `Head` int(11) NULL DEFAULT NULL,
  `HeadFrame` int(11) NULL DEFAULT NULL,
  `AddressId` int(11) NULL DEFAULT NULL,
  `Level` int(11) NULL DEFAULT NULL,
  `Img` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `un_serverId`(`ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 125 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for infraction
-- ----------------------------
DROP TABLE IF EXISTS `infraction`;
CREATE TABLE `infraction`  (
  `AvatarId` bigint(20) NOT NULL DEFAULT 0,
  `ServerId` int(11) NOT NULL DEFAULT 0,
  `Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Level` int(11) NULL DEFAULT NULL,
  `Vip` int(11) NULL DEFAULT NULL,
  `BannedStatus` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `InfractionCount` int(11) NULL DEFAULT NULL,
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `infraction_index`(`AvatarId`, `ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for infractionmessage
-- ----------------------------
DROP TABLE IF EXISTS `infractionmessage`;
CREATE TABLE `infractionmessage`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AvatarId` bigint(20) NOT NULL,
  `KeyWord` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ServerId` int(11) NOT NULL,
  `Content` varchar(5000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Lv` int(11) NULL DEFAULT NULL,
  `Vip` int(11) NULL DEFAULT NULL,
  `Time` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `un_avatarId`(`AvatarId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 39 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for investmentchatmessages
-- ----------------------------
DROP TABLE IF EXISTS `investmentchatmessages`;
CREATE TABLE `investmentchatmessages`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ServerId` int(11) NULL DEFAULT NULL,
  `InvestmentGroupId` int(11) NULL DEFAULT NULL,
  `RoleId` bigint(20) NULL DEFAULT NULL,
  `TitleId` int(11) NULL DEFAULT NULL,
  `Vip` int(11) NULL DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Content` varchar(5000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `DeviceId` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `IDFA` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Time` datetime NULL DEFAULT NULL,
  `Head` int(11) NULL DEFAULT NULL,
  `AddressId` int(11) NULL DEFAULT NULL,
  `HeadFrame` int(11) NULL DEFAULT NULL,
  `Level` int(11) NULL DEFAULT NULL,
  `Img` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for serverchatmessages
-- ----------------------------
DROP TABLE IF EXISTS `serverchatmessages`;
CREATE TABLE `serverchatmessages`  (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ServerId` int(11) NULL DEFAULT NULL,
  `RoleId` bigint(20) NULL DEFAULT NULL,
  `TitleID` int(11) NULL DEFAULT NULL,
  `Vip` int(11) NULL DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Content` varchar(5000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `DeviceId` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `IDFA` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Time` datetime NULL DEFAULT NULL,
  `Head` int(11) NULL DEFAULT NULL,
  `AddressId` int(11) NULL DEFAULT NULL,
  `HeadFrame` int(11) NULL DEFAULT NULL,
  `Level` int(11) NULL DEFAULT NULL,
  `Img` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `un_serverId`(`ServerId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 224 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Procedure structure for load_avatar
-- ----------------------------
DROP PROCEDURE IF EXISTS `load_avatar`;
delimiter ;;
CREATE PROCEDURE `load_avatar`(in avatarId BIGINT(20))
BEGIN
	select * from avatarbase where avatadid = avatarId;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for select_chat_test
-- ----------------------------
DROP PROCEDURE IF EXISTS `select_chat_test`;
delimiter ;;
CREATE PROCEDURE `select_chat_test`()
BEGIN
	DECLARE flag INT DEFAULT 0;
	DECLARE id BIGINT(40);
	DECLARE idList CURSOR FOR SELECT serverid FROM serverchatmessages GROUP BY serverid;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET flag = 1;
	OPEN idList;
		FETCH idList INTO id;
		WHILE flag != 1 DO
				select * from serverchatmessages where serverid = id ORDER BY time LIMIT 50;
				FETCH idList INTO id;
		END WHILE;
	CLOSE idList;
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
